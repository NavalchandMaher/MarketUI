class StrategyModel {
  //==================================================
  // Identity
  //==================================================

  final String id;

  final String strategyName;

  final int version;

  final bool enabled;

  //==================================================
  // EMA
  //==================================================

  final int emaFast;

  final int emaSlow;

  //==================================================
  // RSI
  //==================================================

  final double rsiBuy;

  final double rsiSell;

  //==================================================
  // ADX
  //==================================================

  final double adxMin;

  //==================================================
  // Volume
  //==================================================

  final double volumeRatioMin;

  //==================================================
  // AI Score
  //==================================================

  final int buyThreshold;

  final int sellThreshold;

  //==================================================
  // Risk Management
  //==================================================

  final double tpPercent;

  final double slPercent;

  //==================================================
  // Performance
  //==================================================

  final double winRate;

  final double profitFactor;

  final int totalTrades;

  final int wins;

  final int losses;

  //==================================================
  // Learning
  //==================================================

  final bool aiEnabled;

  final bool paperTrading;

  //==================================================
  // Metadata
  //==================================================

  final DateTime createdAt;

  final DateTime updatedAt;

  const StrategyModel({
    required this.id,
    required this.strategyName,
    required this.version,
    required this.enabled,
    required this.emaFast,
    required this.emaSlow,
    required this.rsiBuy,
    required this.rsiSell,
    required this.adxMin,
    required this.volumeRatioMin,
    required this.buyThreshold,
    required this.sellThreshold,
    required this.tpPercent,
    required this.slPercent,
    required this.winRate,
    required this.profitFactor,
    required this.totalTrades,
    required this.wins,
    required this.losses,
    required this.aiEnabled,
    required this.paperTrading,
    required this.createdAt,
    required this.updatedAt,
  });

  factory StrategyModel.empty() {
    return StrategyModel(
      id: "",
      strategyName: "",
      version: 1,
      enabled: true,
      emaFast: 20,
      emaSlow: 50,
      rsiBuy: 40,
      rsiSell: 65,
      adxMin: 25,
      volumeRatioMin: 1.3,
      buyThreshold: 3,
      sellThreshold: -3,
      tpPercent: 2,
      slPercent: 1,
      winRate: 0,
      profitFactor: 0,
      totalTrades: 0,
      wins: 0,
      losses: 0,
      aiEnabled: true,
      paperTrading: true,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );
  }

  factory StrategyModel.fromJson(Map<String, dynamic> json) {
    return StrategyModel(
      id: json["_id"]?.toString() ?? "",

      strategyName: json["strategy_name"] ?? "",

      version: json["version"] ?? 1,

      enabled: json["enabled"] ?? true,

      emaFast: json["ema_fast"] ?? 20,

      emaSlow: json["ema_slow"] ?? 50,

      rsiBuy: (json["rsi_buy"] ?? 40).toDouble(),

      rsiSell: (json["rsi_sell"] ?? 65).toDouble(),

      adxMin: (json["adx_min"] ?? 25).toDouble(),

      volumeRatioMin:
          (json["volume_ratio_min"] ?? 1.3).toDouble(),

      buyThreshold: json["buy_threshold"] ?? 3,

      sellThreshold: json["sell_threshold"] ?? -3,

      tpPercent:
          (json["tp_percent"] ?? 2).toDouble(),

      slPercent:
          (json["sl_percent"] ?? 1).toDouble(),

      winRate:
          (json["win_rate"] ?? 0).toDouble(),

      profitFactor:
          (json["profit_factor"] ?? 0).toDouble(),

      totalTrades: json["total_trades"] ?? 0,

      wins: json["wins"] ?? 0,

      losses: json["losses"] ?? 0,

      aiEnabled: json["ai_enabled"] ?? true,

      paperTrading: json["paper_trading"] ?? true,

      createdAt: json["created_at"] != null
          ? DateTime.parse(json["created_at"])
          : DateTime.now(),

      updatedAt: json["updated_at"] != null
          ? DateTime.parse(json["updated_at"])
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "_id": id,
      "strategy_name": strategyName,
      "version": version,
      "enabled": enabled,
      "ema_fast": emaFast,
      "ema_slow": emaSlow,
      "rsi_buy": rsiBuy,
      "rsi_sell": rsiSell,
      "adx_min": adxMin,
      "volume_ratio_min": volumeRatioMin,
      "buy_threshold": buyThreshold,
      "sell_threshold": sellThreshold,
      "tp_percent": tpPercent,
      "sl_percent": slPercent,
      "win_rate": winRate,
      "profit_factor": profitFactor,
      "total_trades": totalTrades,
      "wins": wins,
      "losses": losses,
      "ai_enabled": aiEnabled,
      "paper_trading": paperTrading,
      "created_at": createdAt.toIso8601String(),
      "updated_at": updatedAt.toIso8601String(),
    };
  }

  StrategyModel copyWith({
    String? id,
    String? strategyName,
    int? version,
    bool? enabled,
    int? emaFast,
    int? emaSlow,
    double? rsiBuy,
    double? rsiSell,
    double? adxMin,
    double? volumeRatioMin,
    int? buyThreshold,
    int? sellThreshold,
    double? tpPercent,
    double? slPercent,
    double? winRate,
    double? profitFactor,
    int? totalTrades,
    int? wins,
    int? losses,
    bool? aiEnabled,
    bool? paperTrading,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return StrategyModel(
      id: id ?? this.id,
      strategyName: strategyName ?? this.strategyName,
      version: version ?? this.version,
      enabled: enabled ?? this.enabled,
      emaFast: emaFast ?? this.emaFast,
      emaSlow: emaSlow ?? this.emaSlow,
      rsiBuy: rsiBuy ?? this.rsiBuy,
      rsiSell: rsiSell ?? this.rsiSell,
      adxMin: adxMin ?? this.adxMin,
      volumeRatioMin: volumeRatioMin ?? this.volumeRatioMin,
      buyThreshold: buyThreshold ?? this.buyThreshold,
      sellThreshold: sellThreshold ?? this.sellThreshold,
      tpPercent: tpPercent ?? this.tpPercent,
      slPercent: slPercent ?? this.slPercent,
      winRate: winRate ?? this.winRate,
      profitFactor: profitFactor ?? this.profitFactor,
      totalTrades: totalTrades ?? this.totalTrades,
      wins: wins ?? this.wins,
      losses: losses ?? this.losses,
      aiEnabled: aiEnabled ?? this.aiEnabled,
      paperTrading: paperTrading ?? this.paperTrading,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  bool get isProfitable => profitFactor >= 1.2;

  bool get isHighWinRate => winRate >= 60;

  bool get isActive => enabled;

  @override
  String toString() {
    return '''
StrategyModel(
  strategyName: $strategyName,
  version: $version,
  enabled: $enabled,
  winRate: $winRate,
  profitFactor: $profitFactor
)
''';
  }
}