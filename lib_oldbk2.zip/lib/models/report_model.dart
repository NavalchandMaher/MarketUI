class ReportModel {
  //==================================================
  // Identity
  //==================================================

  final String id;

  final String reportId;

  //==================================================
  // Report
  //==================================================

  final String reportName;

  final String reportType;

  // DAILY
  // WEEKLY
  // MONTHLY
  // BACKTEST
  // PERFORMANCE
  // AI

  //==================================================
  // Strategy
  //==================================================

  final String strategyName;

  final int strategyVersion;

  //==================================================
  // Market
  //==================================================

  final String symbol;

  final String timeframe;

  final int days;

  //==================================================
  // Performance
  //==================================================

  final int totalTrades;

  final int wins;

  final int losses;

  final double winRate;

  final double grossProfit;

  final double grossLoss;

  final double netProfit;

  final double profitFactor;

  final double sharpeRatio;

  final double drawdown;

  final double expectancy;

  //==================================================
  // AI
  //==================================================

  final double averageConfidence;

  final String marketRegime;

  final String recommendation;

  final String summary;

  //==================================================
  // Report Status
  //==================================================

  final String status;

  final bool archived;

  //==================================================
  // Metadata
  //==================================================

  final DateTime createdAt;

  final DateTime updatedAt;

  const ReportModel({
    required this.id,
    required this.reportId,
    required this.reportName,
    required this.reportType,
    required this.strategyName,
    required this.strategyVersion,
    required this.symbol,
    required this.timeframe,
    required this.days,
    required this.totalTrades,
    required this.wins,
    required this.losses,
    required this.winRate,
    required this.grossProfit,
    required this.grossLoss,
    required this.netProfit,
    required this.profitFactor,
    required this.sharpeRatio,
    required this.drawdown,
    required this.expectancy,
    required this.averageConfidence,
    required this.marketRegime,
    required this.recommendation,
    required this.summary,
    required this.status,
    required this.archived,
    required this.createdAt,
    required this.updatedAt,
  });

  factory ReportModel.empty() {
    return ReportModel(
      id: "",
      reportId: "",
      reportName: "",
      reportType: "DAILY",
      strategyName: "",
      strategyVersion: 1,
      symbol: "",
      timeframe: "",
      days: 30,
      totalTrades: 0,
      wins: 0,
      losses: 0,
      winRate: 0,
      grossProfit: 0,
      grossLoss: 0,
      netProfit: 0,
      profitFactor: 0,
      sharpeRatio: 0,
      drawdown: 0,
      expectancy: 0,
      averageConfidence: 0,
      marketRegime: "",
      recommendation: "",
      summary: "",
      status: "GENERATED",
      archived: false,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );
  }

  factory ReportModel.fromJson(Map<String, dynamic> json) {
    return ReportModel(
      id: json["_id"]?.toString() ?? "",
      reportId: json["report_id"] ?? "",
      reportName: json["report_name"] ?? "",
      reportType: json["report_type"] ?? "DAILY",
      strategyName: json["strategy_name"] ?? "",
      strategyVersion: json["strategy_version"] ?? 1,
      symbol: json["symbol"] ?? "",
      timeframe: json["timeframe"] ?? "",
      days: json["days"] ?? 30,
      totalTrades: json["total_trades"] ?? 0,
      wins: json["wins"] ?? 0,
      losses: json["losses"] ?? 0,
      winRate: (json["win_rate"] ?? 0).toDouble(),
      grossProfit: (json["gross_profit"] ?? 0).toDouble(),
      grossLoss: (json["gross_loss"] ?? 0).toDouble(),
      netProfit: (json["net_profit"] ?? 0).toDouble(),
      profitFactor: (json["profit_factor"] ?? 0).toDouble(),
      sharpeRatio: (json["sharpe_ratio"] ?? 0).toDouble(),
      drawdown: (json["drawdown"] ?? 0).toDouble(),
      expectancy: (json["expectancy"] ?? 0).toDouble(),
      averageConfidence:
          (json["average_confidence"] ?? 0).toDouble(),
      marketRegime: json["market_regime"] ?? "",
      recommendation: json["recommendation"] ?? "",
      summary: json["summary"] ?? "",
      status: json["status"] ?? "GENERATED",
      archived: json["archived"] ?? false,
      createdAt: json["created_at"] != null
          ? DateTime.parse(json["created_at"])
          : DateTime.now(),
      updatedAt: json["updated_at"] != null
          ? DateTime.parse(json["updated_at"])
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "_id": id,
      "report_id": reportId,
      "report_name": reportName,
      "report_type": reportType,
      "strategy_name": strategyName,
      "strategy_version": strategyVersion,
      "symbol": symbol,
      "timeframe": timeframe,
      "days": days,
      "total_trades": totalTrades,
      "wins": wins,
      "losses": losses,
      "win_rate": winRate,
      "gross_profit": grossProfit,
      "gross_loss": grossLoss,
      "net_profit": netProfit,
      "profit_factor": profitFactor,
      "sharpe_ratio": sharpeRatio,
      "drawdown": drawdown,
      "expectancy": expectancy,
      "average_confidence": averageConfidence,
      "market_regime": marketRegime,
      "recommendation": recommendation,
      "summary": summary,
      "status": status,
      "archived": archived,
      "created_at": createdAt.toIso8601String(),
      "updated_at": updatedAt.toIso8601String(),
    };
  }

  ReportModel copyWith({
    String? id,
    String? reportId,
    String? reportName,
    String? reportType,
    String? strategyName,
    int? strategyVersion,
    String? symbol,
    String? timeframe,
    int? days,
    int? totalTrades,
    int? wins,
    int? losses,
    double? winRate,
    double? grossProfit,
    double? grossLoss,
    double? netProfit,
    double? profitFactor,
    double? sharpeRatio,
    double? drawdown,
    double? expectancy,
    double? averageConfidence,
    String? marketRegime,
    String? recommendation,
    String? summary,
    String? status,
    bool? archived,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return ReportModel(
      id: id ?? this.id,
      reportId: reportId ?? this.reportId,
      reportName: reportName ?? this.reportName,
      reportType: reportType ?? this.reportType,
      strategyName: strategyName ?? this.strategyName,
      strategyVersion: strategyVersion ?? this.strategyVersion,
      symbol: symbol ?? this.symbol,
      timeframe: timeframe ?? this.timeframe,
      days: days ?? this.days,
      totalTrades: totalTrades ?? this.totalTrades,
      wins: wins ?? this.wins,
      losses: losses ?? this.losses,
      winRate: winRate ?? this.winRate,
      grossProfit: grossProfit ?? this.grossProfit,
      grossLoss: grossLoss ?? this.grossLoss,
      netProfit: netProfit ?? this.netProfit,
      profitFactor: profitFactor ?? this.profitFactor,
      sharpeRatio: sharpeRatio ?? this.sharpeRatio,
      drawdown: drawdown ?? this.drawdown,
      expectancy: expectancy ?? this.expectancy,
      averageConfidence:
          averageConfidence ?? this.averageConfidence,
      marketRegime: marketRegime ?? this.marketRegime,
      recommendation: recommendation ?? this.recommendation,
      summary: summary ?? this.summary,
      status: status ?? this.status,
      archived: archived ?? this.archived,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  bool get isProfitable => netProfit > 0;

  bool get isArchived => archived;

  bool get isBacktest =>
      reportType.toUpperCase() == "BACKTEST";

  bool get isPerformance =>
      reportType.toUpperCase() == "PERFORMANCE";

  @override
  String toString() {
    return '''
ReportModel(
  reportName: $reportName
  strategy: $strategyName
  netProfit: $netProfit
  reportType: $reportType
)
''';
  }
}