class SchedulerModel {
  //==================================================
  // Identity
  //==================================================

  final String id;

  //==================================================
  // Scheduler
  //==================================================

  final bool isRunning;

  final bool marketCycleRunning;

  final bool paperTradingRunning;

  final bool learningRunning;

  final bool nightlyLearningRunning;

  final bool performanceRunning;

  final bool strategyOptimizationRunning;

  //==================================================
  // Timing
  //==================================================

  final DateTime? lastMarketCycle;

  final DateTime? nextMarketCycle;

  final DateTime? lastLearning;

  final DateTime? nextLearning;

  final DateTime? lastNightlyLearning;

  final DateTime? nextNightlyLearning;

  //==================================================
  // Statistics
  //==================================================

  final int totalExecutions;

  final int successfulExecutions;

  final int failedExecutions;

  final int pendingJobs;

  //==================================================
  // Health
  //==================================================

  final String status;

  final String lastError;

  final double uptimePercentage;

  //==================================================
  // Created
  //==================================================

  final DateTime createdAt;

  final DateTime updatedAt;

  const SchedulerModel({
    required this.id,
    required this.isRunning,
    required this.marketCycleRunning,
    required this.paperTradingRunning,
    required this.learningRunning,
    required this.nightlyLearningRunning,
    required this.performanceRunning,
    required this.strategyOptimizationRunning,
    required this.lastMarketCycle,
    required this.nextMarketCycle,
    required this.lastLearning,
    required this.nextLearning,
    required this.lastNightlyLearning,
    required this.nextNightlyLearning,
    required this.totalExecutions,
    required this.successfulExecutions,
    required this.failedExecutions,
    required this.pendingJobs,
    required this.status,
    required this.lastError,
    required this.uptimePercentage,
    required this.createdAt,
    required this.updatedAt,
  });

  factory SchedulerModel.empty() {
    return SchedulerModel(
      id: "",
      isRunning: false,
      marketCycleRunning: false,
      paperTradingRunning: false,
      learningRunning: false,
      nightlyLearningRunning: false,
      performanceRunning: false,
      strategyOptimizationRunning: false,
      lastMarketCycle: null,
      nextMarketCycle: null,
      lastLearning: null,
      nextLearning: null,
      lastNightlyLearning: null,
      nextNightlyLearning: null,
      totalExecutions: 0,
      successfulExecutions: 0,
      failedExecutions: 0,
      pendingJobs: 0,
      status: "STOPPED",
      lastError: "",
      uptimePercentage: 0,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );
  }

  factory SchedulerModel.fromJson(Map<String, dynamic> json) {
    DateTime? parseDate(dynamic value) {
      if (value == null) return null;
      return DateTime.tryParse(value.toString());
    }

    return SchedulerModel(
      id: json["_id"]?.toString() ?? "",
      isRunning: json["is_running"] ?? false,
      marketCycleRunning: json["market_cycle_running"] ?? false,
      paperTradingRunning: json["paper_trading_running"] ?? false,
      learningRunning: json["learning_running"] ?? false,
      nightlyLearningRunning: json["nightly_learning_running"] ?? false,
      performanceRunning: json["performance_running"] ?? false,
      strategyOptimizationRunning:
          json["strategy_optimization_running"] ?? false,
      lastMarketCycle: parseDate(json["last_market_cycle"]),
      nextMarketCycle: parseDate(json["next_market_cycle"]),
      lastLearning: parseDate(json["last_learning"]),
      nextLearning: parseDate(json["next_learning"]),
      lastNightlyLearning: parseDate(json["last_nightly_learning"]),
      nextNightlyLearning: parseDate(json["next_nightly_learning"]),
      totalExecutions: json["total_executions"] ?? 0,
      successfulExecutions: json["successful_executions"] ?? 0,
      failedExecutions: json["failed_executions"] ?? 0,
      pendingJobs: json["pending_jobs"] ?? 0,
      status: json["status"] ?? "STOPPED",
      lastError: json["last_error"] ?? "",
      uptimePercentage: (json["uptime_percentage"] ?? 0).toDouble(),
      createdAt: parseDate(json["created_at"]) ?? DateTime.now(),
      updatedAt: parseDate(json["updated_at"]) ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "_id": id,
      "is_running": isRunning,
      "market_cycle_running": marketCycleRunning,
      "paper_trading_running": paperTradingRunning,
      "learning_running": learningRunning,
      "nightly_learning_running": nightlyLearningRunning,
      "performance_running": performanceRunning,
      "strategy_optimization_running": strategyOptimizationRunning,
      "last_market_cycle": lastMarketCycle?.toIso8601String(),
      "next_market_cycle": nextMarketCycle?.toIso8601String(),
      "last_learning": lastLearning?.toIso8601String(),
      "next_learning": nextLearning?.toIso8601String(),
      "last_nightly_learning":
          lastNightlyLearning?.toIso8601String(),
      "next_nightly_learning":
          nextNightlyLearning?.toIso8601String(),
      "total_executions": totalExecutions,
      "successful_executions": successfulExecutions,
      "failed_executions": failedExecutions,
      "pending_jobs": pendingJobs,
      "status": status,
      "last_error": lastError,
      "uptime_percentage": uptimePercentage,
      "created_at": createdAt.toIso8601String(),
      "updated_at": updatedAt.toIso8601String(),
    };
  }

  SchedulerModel copyWith({
    String? id,
    bool? isRunning,
    bool? marketCycleRunning,
    bool? paperTradingRunning,
    bool? learningRunning,
    bool? nightlyLearningRunning,
    bool? performanceRunning,
    bool? strategyOptimizationRunning,
    DateTime? lastMarketCycle,
    DateTime? nextMarketCycle,
    DateTime? lastLearning,
    DateTime? nextLearning,
    DateTime? lastNightlyLearning,
    DateTime? nextNightlyLearning,
    int? totalExecutions,
    int? successfulExecutions,
    int? failedExecutions,
    int? pendingJobs,
    String? status,
    String? lastError,
    double? uptimePercentage,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return SchedulerModel(
      id: id ?? this.id,
      isRunning: isRunning ?? this.isRunning,
      marketCycleRunning:
          marketCycleRunning ?? this.marketCycleRunning,
      paperTradingRunning:
          paperTradingRunning ?? this.paperTradingRunning,
      learningRunning: learningRunning ?? this.learningRunning,
      nightlyLearningRunning:
          nightlyLearningRunning ?? this.nightlyLearningRunning,
      performanceRunning:
          performanceRunning ?? this.performanceRunning,
      strategyOptimizationRunning:
          strategyOptimizationRunning ??
              this.strategyOptimizationRunning,
      lastMarketCycle:
          lastMarketCycle ?? this.lastMarketCycle,
      nextMarketCycle:
          nextMarketCycle ?? this.nextMarketCycle,
      lastLearning: lastLearning ?? this.lastLearning,
      nextLearning: nextLearning ?? this.nextLearning,
      lastNightlyLearning:
          lastNightlyLearning ?? this.lastNightlyLearning,
      nextNightlyLearning:
          nextNightlyLearning ?? this.nextNightlyLearning,
      totalExecutions:
          totalExecutions ?? this.totalExecutions,
      successfulExecutions:
          successfulExecutions ??
              this.successfulExecutions,
      failedExecutions:
          failedExecutions ?? this.failedExecutions,
      pendingJobs: pendingJobs ?? this.pendingJobs,
      status: status ?? this.status,
      lastError: lastError ?? this.lastError,
      uptimePercentage:
          uptimePercentage ?? this.uptimePercentage,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  bool get isHealthy =>
      status.toUpperCase() == "RUNNING" &&
      lastError.isEmpty;

  bool get hasFailures => failedExecutions > 0;

  bool get hasPendingJobs => pendingJobs > 0;

  @override
  String toString() {
    return '''
SchedulerModel(
  status: $status
  running: $isRunning
  executions: $totalExecutions
  success: $successfulExecutions
  failed: $failedExecutions
)
''';
  }
}