class LearningLogModel {
  //==================================================
  // Identity
  //==================================================

  final String id;

  final String learningId;

  //==================================================
  // Strategy
  //==================================================

  final String strategyName;

  final int strategyVersion;

  //==================================================
  // Market
  //==================================================

  final String symbol;

  final String timeframe;

  final String marketRegime;

  //==================================================
  // Learning
  //==================================================

  final String learningType;

  // NIGHTLY
  // ONLINE
  // MANUAL
  // BACKTEST

  final String action;

  final String description;

  //==================================================
  // Performance Before
  //==================================================

  final double previousWinRate;

  final double previousProfitFactor;

  final double previousNetProfit;

  //==================================================
  // Performance After
  //==================================================

  final double newWinRate;

  final double newProfitFactor;

  final double newNetProfit;

  //==================================================
  // AI Confidence
  //==================================================

  final double confidence;

  final bool improvement;

  //==================================================
  // Parameters Changed
  //==================================================

  final Map<String, dynamic> oldParameters;

  final Map<String, dynamic> newParameters;

  //==================================================
  // Statistics
  //==================================================

  final int tradesAnalyzed;

  final int tradesImproved;

  final int tradesRejected;

  //==================================================
  // Execution
  //==================================================

  final bool success;

  final String message;

  final String error;

  //==================================================
  // Time
  //==================================================

  final DateTime createdAt;

  const LearningLogModel({
    required this.id,
    required this.learningId,
    required this.strategyName,
    required this.strategyVersion,
    required this.symbol,
    required this.timeframe,
    required this.marketRegime,
    required this.learningType,
    required this.action,
    required this.description,
    required this.previousWinRate,
    required this.previousProfitFactor,
    required this.previousNetProfit,
    required this.newWinRate,
    required this.newProfitFactor,
    required this.newNetProfit,
    required this.confidence,
    required this.improvement,
    required this.oldParameters,
    required this.newParameters,
    required this.tradesAnalyzed,
    required this.tradesImproved,
    required this.tradesRejected,
    required this.success,
    required this.message,
    required this.error,
    required this.createdAt,
  });

  factory LearningLogModel.empty() {
    return LearningLogModel(
      id: "",
      learningId: "",
      strategyName: "",
      strategyVersion: 1,
      symbol: "",
      timeframe: "",
      marketRegime: "",
      learningType: "NIGHTLY",
      action: "",
      description: "",
      previousWinRate: 0,
      previousProfitFactor: 0,
      previousNetProfit: 0,
      newWinRate: 0,
      newProfitFactor: 0,
      newNetProfit: 0,
      confidence: 0,
      improvement: false,
      oldParameters: {},
      newParameters: {},
      tradesAnalyzed: 0,
      tradesImproved: 0,
      tradesRejected: 0,
      success: true,
      message: "",
      error: "",
      createdAt: DateTime.now(),
    );
  }

  factory LearningLogModel.fromJson(Map<String, dynamic> json) {
    return LearningLogModel(
      id: json["_id"]?.toString() ?? "",
      learningId: json["learning_id"] ?? "",
      strategyName: json["strategy_name"] ?? "",
      strategyVersion: json["strategy_version"] ?? 1,
      symbol: json["symbol"] ?? "",
      timeframe: json["timeframe"] ?? "",
      marketRegime: json["market_regime"] ?? "",
      learningType: json["learning_type"] ?? "NIGHTLY",
      action: json["action"] ?? "",
      description: json["description"] ?? "",
      previousWinRate: (json["previous_win_rate"] ?? 0).toDouble(),
      previousProfitFactor:
          (json["previous_profit_factor"] ?? 0).toDouble(),
      previousNetProfit:
          (json["previous_net_profit"] ?? 0).toDouble(),
      newWinRate: (json["new_win_rate"] ?? 0).toDouble(),
      newProfitFactor:
          (json["new_profit_factor"] ?? 0).toDouble(),
      newNetProfit:
          (json["new_net_profit"] ?? 0).toDouble(),
      confidence: (json["confidence"] ?? 0).toDouble(),
      improvement: json["improvement"] ?? false,
      oldParameters: Map<String, dynamic>.from(
          json["old_parameters"] ?? {}),
      newParameters: Map<String, dynamic>.from(
          json["new_parameters"] ?? {}),
      tradesAnalyzed: json["trades_analyzed"] ?? 0,
      tradesImproved: json["trades_improved"] ?? 0,
      tradesRejected: json["trades_rejected"] ?? 0,
      success: json["success"] ?? true,
      message: json["message"] ?? "",
      error: json["error"] ?? "",
      createdAt: json["created_at"] != null
          ? DateTime.parse(json["created_at"])
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "_id": id,
      "learning_id": learningId,
      "strategy_name": strategyName,
      "strategy_version": strategyVersion,
      "symbol": symbol,
      "timeframe": timeframe,
      "market_regime": marketRegime,
      "learning_type": learningType,
      "action": action,
      "description": description,
      "previous_win_rate": previousWinRate,
      "previous_profit_factor": previousProfitFactor,
      "previous_net_profit": previousNetProfit,
      "new_win_rate": newWinRate,
      "new_profit_factor": newProfitFactor,
      "new_net_profit": newNetProfit,
      "confidence": confidence,
      "improvement": improvement,
      "old_parameters": oldParameters,
      "new_parameters": newParameters,
      "trades_analyzed": tradesAnalyzed,
      "trades_improved": tradesImproved,
      "trades_rejected": tradesRejected,
      "success": success,
      "message": message,
      "error": error,
      "created_at": createdAt.toIso8601String(),
    };
  }

  LearningLogModel copyWith({
    String? id,
    String? learningId,
    String? strategyName,
    int? strategyVersion,
    String? symbol,
    String? timeframe,
    String? marketRegime,
    String? learningType,
    String? action,
    String? description,
    double? previousWinRate,
    double? previousProfitFactor,
    double? previousNetProfit,
    double? newWinRate,
    double? newProfitFactor,
    double? newNetProfit,
    double? confidence,
    bool? improvement,
    Map<String, dynamic>? oldParameters,
    Map<String, dynamic>? newParameters,
    int? tradesAnalyzed,
    int? tradesImproved,
    int? tradesRejected,
    bool? success,
    String? message,
    String? error,
    DateTime? createdAt,
  }) {
    return LearningLogModel(
      id: id ?? this.id,
      learningId: learningId ?? this.learningId,
      strategyName: strategyName ?? this.strategyName,
      strategyVersion: strategyVersion ?? this.strategyVersion,
      symbol: symbol ?? this.symbol,
      timeframe: timeframe ?? this.timeframe,
      marketRegime: marketRegime ?? this.marketRegime,
      learningType: learningType ?? this.learningType,
      action: action ?? this.action,
      description: description ?? this.description,
      previousWinRate: previousWinRate ?? this.previousWinRate,
      previousProfitFactor:
          previousProfitFactor ?? this.previousProfitFactor,
      previousNetProfit:
          previousNetProfit ?? this.previousNetProfit,
      newWinRate: newWinRate ?? this.newWinRate,
      newProfitFactor:
          newProfitFactor ?? this.newProfitFactor,
      newNetProfit: newNetProfit ?? this.newNetProfit,
      confidence: confidence ?? this.confidence,
      improvement: improvement ?? this.improvement,
      oldParameters: oldParameters ?? this.oldParameters,
      newParameters: newParameters ?? this.newParameters,
      tradesAnalyzed: tradesAnalyzed ?? this.tradesAnalyzed,
      tradesImproved: tradesImproved ?? this.tradesImproved,
      tradesRejected: tradesRejected ?? this.tradesRejected,
      success: success ?? this.success,
      message: message ?? this.message,
      error: error ?? this.error,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  bool get isSuccessful => success;

  bool get hasImproved => improvement;

  double get winRateDifference =>
      newWinRate - previousWinRate;

  double get profitFactorDifference =>
      newProfitFactor - previousProfitFactor;

  @override
  String toString() {
    return '''
LearningLogModel(
  strategy: $strategyName
  learningType: $learningType
  improvement: $improvement
  confidence: $confidence
)
''';
  }
}