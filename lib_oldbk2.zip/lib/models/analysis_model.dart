class AnalysisModel {
  //==================================================
  // Market
  //==================================================

  final String symbol;
  final String timeframe;

  final double price;

  //==================================================
  // Signal
  //==================================================

  final String signal;
  final double confidence;

  //==================================================
  // Indicators
  //==================================================

  final double rsi;
  final double ema20;
  final double ema50;
  final double ema200;

  final double macd;
  final double macdSignal;

  final double adx;

  final double volumeRatio;

  //==================================================
  // Support / Resistance
  //==================================================

  final double support;
  final double resistance;

  //==================================================
  // AI
  //==================================================

  final String marketSentiment;
  final String marketRegime;

  final String aiReason;

  //==================================================
  // Risk Management
  //==================================================

  final double stopLoss;
  final double targetPrice;

  final double riskReward;

  //==================================================
  // Time
  //==================================================

  final DateTime createdAt;

  const AnalysisModel({
    required this.symbol,
    required this.timeframe,
    required this.price,
    required this.signal,
    required this.confidence,
    required this.rsi,
    required this.ema20,
    required this.ema50,
    required this.ema200,
    required this.macd,
    required this.macdSignal,
    required this.adx,
    required this.volumeRatio,
    required this.support,
    required this.resistance,
    required this.marketSentiment,
    required this.marketRegime,
    required this.aiReason,
    required this.stopLoss,
    required this.targetPrice,
    required this.riskReward,
    required this.createdAt,
  });

  factory AnalysisModel.empty() {
    return AnalysisModel(
      symbol: "",
      timeframe: "",
      price: 0,
      signal: "WAIT",
      confidence: 0,
      rsi: 0,
      ema20: 0,
      ema50: 0,
      ema200: 0,
      macd: 0,
      macdSignal: 0,
      adx: 0,
      volumeRatio: 0,
      support: 0,
      resistance: 0,
      marketSentiment: "NEUTRAL",
      marketRegime: "RANGING",
      aiReason: "",
      stopLoss: 0,
      targetPrice: 0,
      riskReward: 0,
      createdAt: DateTime.now(),
    );
  }

  factory AnalysisModel.fromJson(Map<String, dynamic> json) {
    return AnalysisModel(
      symbol: json["symbol"] ?? "",
      timeframe: json["timeframe"] ?? "",
      price: (json["price"] ?? 0).toDouble(),

      signal: json["signal"] ?? "WAIT",
      confidence: (json["confidence"] ?? 0).toDouble(),

      rsi: (json["rsi"] ?? 0).toDouble(),
      ema20: (json["ema20"] ?? 0).toDouble(),
      ema50: (json["ema50"] ?? 0).toDouble(),
      ema200: (json["ema200"] ?? 0).toDouble(),

      macd: (json["macd"] ?? 0).toDouble(),
      macdSignal: (json["macdSignal"] ?? 0).toDouble(),

      adx: (json["adx"] ?? 0).toDouble(),
      volumeRatio: (json["volumeRatio"] ?? 0).toDouble(),

      support: (json["support"] ?? 0).toDouble(),
      resistance: (json["resistance"] ?? 0).toDouble(),

      marketSentiment: json["marketSentiment"] ?? "NEUTRAL",
      marketRegime: json["marketRegime"] ?? "RANGING",

      aiReason: json["aiReason"] ?? "",

      stopLoss: (json["stopLoss"] ?? 0).toDouble(),
      targetPrice: (json["targetPrice"] ?? 0).toDouble(),
      riskReward: (json["riskReward"] ?? 0).toDouble(),

      createdAt: json["createdAt"] != null
          ? DateTime.parse(json["createdAt"])
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "symbol": symbol,
      "timeframe": timeframe,
      "price": price,
      "signal": signal,
      "confidence": confidence,
      "rsi": rsi,
      "ema20": ema20,
      "ema50": ema50,
      "ema200": ema200,
      "macd": macd,
      "macdSignal": macdSignal,
      "adx": adx,
      "volumeRatio": volumeRatio,
      "support": support,
      "resistance": resistance,
      "marketSentiment": marketSentiment,
      "marketRegime": marketRegime,
      "aiReason": aiReason,
      "stopLoss": stopLoss,
      "targetPrice": targetPrice,
      "riskReward": riskReward,
      "createdAt": createdAt.toIso8601String(),
    };
  }

  AnalysisModel copyWith({
    String? symbol,
    String? timeframe,
    double? price,
    String? signal,
    double? confidence,
    double? rsi,
    double? ema20,
    double? ema50,
    double? ema200,
    double? macd,
    double? macdSignal,
    double? adx,
    double? volumeRatio,
    double? support,
    double? resistance,
    String? marketSentiment,
    String? marketRegime,
    String? aiReason,
    double? stopLoss,
    double? targetPrice,
    double? riskReward,
    DateTime? createdAt,
  }) {
    return AnalysisModel(
      symbol: symbol ?? this.symbol,
      timeframe: timeframe ?? this.timeframe,
      price: price ?? this.price,
      signal: signal ?? this.signal,
      confidence: confidence ?? this.confidence,
      rsi: rsi ?? this.rsi,
      ema20: ema20 ?? this.ema20,
      ema50: ema50 ?? this.ema50,
      ema200: ema200 ?? this.ema200,
      macd: macd ?? this.macd,
      macdSignal: macdSignal ?? this.macdSignal,
      adx: adx ?? this.adx,
      volumeRatio: volumeRatio ?? this.volumeRatio,
      support: support ?? this.support,
      resistance: resistance ?? this.resistance,
      marketSentiment: marketSentiment ?? this.marketSentiment,
      marketRegime: marketRegime ?? this.marketRegime,
      aiReason: aiReason ?? this.aiReason,
      stopLoss: stopLoss ?? this.stopLoss,
      targetPrice: targetPrice ?? this.targetPrice,
      riskReward: riskReward ?? this.riskReward,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  bool get isBuy => signal.toUpperCase() == "BUY";

  bool get isSell => signal.toUpperCase() == "SELL";

  bool get isWait => signal.toUpperCase() == "WAIT";

  @override
  String toString() {
    return "AnalysisModel(symbol: $symbol, signal: $signal, confidence: $confidence)";
  }
}