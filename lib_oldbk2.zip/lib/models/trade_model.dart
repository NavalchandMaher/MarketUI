class TradeModel {
  //==================================================
  // Trade Identity
  //==================================================

  final String id;
  final String tradeId;

  //==================================================
  // Market
  //==================================================

  final String symbol;
  final String timeframe;

  //==================================================
  // Strategy
  //==================================================

  final String strategyName;
  final int strategyVersion;

  //==================================================
  // Signal
  //==================================================

  final String signal;
  final double confidence;

  //==================================================
  // Prices
  //==================================================

  final double entryPrice;
  final double exitPrice;

  final double stopLoss;
  final double takeProfit;

  //==================================================
  // Quantity
  //==================================================

  final double quantity;
  final double investment;

  //==================================================
  // Profit
  //==================================================

  final double pnl;
  final double pnlPercent;

  //==================================================
  // Status
  //==================================================

  final String status;

  // OPEN
  // CLOSED
  // CANCELLED

  final bool isWinner;

  //==================================================
  // AI
  //==================================================

  final String marketRegime;

  final Map<String, dynamic> indicators;

  //==================================================
  // Time
  //==================================================

  final DateTime openTime;
  final DateTime? closeTime;

  const TradeModel({
    required this.id,
    required this.tradeId,
    required this.symbol,
    required this.timeframe,
    required this.strategyName,
    required this.strategyVersion,
    required this.signal,
    required this.confidence,
    required this.entryPrice,
    required this.exitPrice,
    required this.stopLoss,
    required this.takeProfit,
    required this.quantity,
    required this.investment,
    required this.pnl,
    required this.pnlPercent,
    required this.status,
    required this.isWinner,
    required this.marketRegime,
    required this.indicators,
    required this.openTime,
    this.closeTime,
  });

  factory TradeModel.empty() {
    return TradeModel(
      id: "",
      tradeId: "",
      symbol: "",
      timeframe: "",
      strategyName: "",
      strategyVersion: 1,
      signal: "WAIT",
      confidence: 0,
      entryPrice: 0,
      exitPrice: 0,
      stopLoss: 0,
      takeProfit: 0,
      quantity: 0,
      investment: 0,
      pnl: 0,
      pnlPercent: 0,
      status: "OPEN",
      isWinner: false,
      marketRegime: "",
      indicators: {},
      openTime: DateTime.now(),
      closeTime: null,
    );
  }

  factory TradeModel.fromJson(Map<String, dynamic> json) {
    return TradeModel(
      id: json["_id"]?.toString() ?? "",
      tradeId: json["trade_id"] ?? "",

      symbol: json["symbol"] ?? "",
      timeframe: json["timeframe"] ?? "",

      strategyName: json["strategy_name"] ?? "",
      strategyVersion: json["strategy_version"] ?? 1,

      signal: json["signal"] ?? "WAIT",
      confidence: (json["confidence"] ?? 0).toDouble(),

      entryPrice: (json["entry_price"] ?? 0).toDouble(),
      exitPrice: (json["exit_price"] ?? 0).toDouble(),

      stopLoss: (json["stop_loss"] ?? 0).toDouble(),
      takeProfit: (json["take_profit"] ?? 0).toDouble(),

      quantity: (json["quantity"] ?? 0).toDouble(),
      investment: (json["investment"] ?? 0).toDouble(),

      pnl: (json["pnl"] ?? 0).toDouble(),
      pnlPercent: (json["pnl_percent"] ?? 0).toDouble(),

      status: json["status"] ?? "OPEN",

      isWinner: json["is_winner"] ?? false,

      marketRegime: json["market_regime"] ?? "",

      indicators: json["indicators"] ?? {},

      openTime: json["open_time"] != null
          ? DateTime.parse(json["open_time"])
          : DateTime.now(),

      closeTime: json["close_time"] != null
          ? DateTime.parse(json["close_time"])
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "_id": id,
      "trade_id": tradeId,
      "symbol": symbol,
      "timeframe": timeframe,
      "strategy_name": strategyName,
      "strategy_version": strategyVersion,
      "signal": signal,
      "confidence": confidence,
      "entry_price": entryPrice,
      "exit_price": exitPrice,
      "stop_loss": stopLoss,
      "take_profit": takeProfit,
      "quantity": quantity,
      "investment": investment,
      "pnl": pnl,
      "pnl_percent": pnlPercent,
      "status": status,
      "is_winner": isWinner,
      "market_regime": marketRegime,
      "indicators": indicators,
      "open_time": openTime.toIso8601String(),
      "close_time": closeTime?.toIso8601String(),
    };
  }

  TradeModel copyWith({
    String? id,
    String? tradeId,
    String? symbol,
    String? timeframe,
    String? strategyName,
    int? strategyVersion,
    String? signal,
    double? confidence,
    double? entryPrice,
    double? exitPrice,
    double? stopLoss,
    double? takeProfit,
    double? quantity,
    double? investment,
    double? pnl,
    double? pnlPercent,
    String? status,
    bool? isWinner,
    String? marketRegime,
    Map<String, dynamic>? indicators,
    DateTime? openTime,
    DateTime? closeTime,
  }) {
    return TradeModel(
      id: id ?? this.id,
      tradeId: tradeId ?? this.tradeId,
      symbol: symbol ?? this.symbol,
      timeframe: timeframe ?? this.timeframe,
      strategyName: strategyName ?? this.strategyName,
      strategyVersion: strategyVersion ?? this.strategyVersion,
      signal: signal ?? this.signal,
      confidence: confidence ?? this.confidence,
      entryPrice: entryPrice ?? this.entryPrice,
      exitPrice: exitPrice ?? this.exitPrice,
      stopLoss: stopLoss ?? this.stopLoss,
      takeProfit: takeProfit ?? this.takeProfit,
      quantity: quantity ?? this.quantity,
      investment: investment ?? this.investment,
      pnl: pnl ?? this.pnl,
      pnlPercent: pnlPercent ?? this.pnlPercent,
      status: status ?? this.status,
      isWinner: isWinner ?? this.isWinner,
      marketRegime: marketRegime ?? this.marketRegime,
      indicators: indicators ?? this.indicators,
      openTime: openTime ?? this.openTime,
      closeTime: closeTime ?? this.closeTime,
    );
  }

  bool get isOpen => status.toUpperCase() == "OPEN";

  bool get isClosed => status.toUpperCase() == "CLOSED";

  bool get isBuy => signal.toUpperCase() == "BUY";

  bool get isSell => signal.toUpperCase() == "SELL";

  @override
  String toString() {
    return "TradeModel(tradeId: $tradeId, symbol: $symbol, signal: $signal, pnl: $pnl)";
  }
}