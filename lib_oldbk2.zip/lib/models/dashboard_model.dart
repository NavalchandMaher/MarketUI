class DashboardModel {
  //==================================================
  // Market
  //==================================================

  final double btcPrice;
  final double btcChange;

  final double ethPrice;
  final double ethChange;

  final String marketSentiment;
  final String marketRegime;

  final String fearGreed;
  final String volatility;

  //==================================================
  // Signal
  //==================================================

  final String currentSignal;
  final double confidence;

  //==================================================
  // Performance
  //==================================================

  final double todayPnL;

  final int totalTrades;
  final int openTrades;

  final double winRate;

  //==================================================
  // Strategy
  //==================================================

  final String activeStrategy;
  final int strategyVersion;

  //==================================================
  // Scheduler
  //==================================================

  final bool schedulerRunning;

  //==================================================
  // Learning
  //==================================================

  final String lastLearning;

  //==================================================
  // Misc
  //==================================================

  final DateTime lastUpdated;

  const DashboardModel({
    required this.btcPrice,
    required this.btcChange,
    required this.ethPrice,
    required this.ethChange,
    required this.marketSentiment,
    required this.marketRegime,
    required this.fearGreed,
    required this.volatility,
    required this.currentSignal,
    required this.confidence,
    required this.todayPnL,
    required this.totalTrades,
    required this.openTrades,
    required this.winRate,
    required this.activeStrategy,
    required this.strategyVersion,
    required this.schedulerRunning,
    required this.lastLearning,
    required this.lastUpdated,
  });

  factory DashboardModel.empty() {
    return DashboardModel(
      btcPrice: 0,
      btcChange: 0,
      ethPrice: 0,
      ethChange: 0,
      marketSentiment: "NEUTRAL",
      marketRegime: "RANGING",
      fearGreed: "Neutral",
      volatility: "Low",
      currentSignal: "WAIT",
      confidence: 0,
      todayPnL: 0,
      totalTrades: 0,
      openTrades: 0,
      winRate: 0,
      activeStrategy: "N/A",
      strategyVersion: 1,
      schedulerRunning: false,
      lastLearning: "",
      lastUpdated: DateTime.now(),
    );
  }

  factory DashboardModel.fromJson(Map<String, dynamic> json) {
    return DashboardModel(
      btcPrice: (json["btcPrice"] ?? 0).toDouble(),
      btcChange: (json["btcChange"] ?? 0).toDouble(),
      ethPrice: (json["ethPrice"] ?? 0).toDouble(),
      ethChange: (json["ethChange"] ?? 0).toDouble(),

      marketSentiment: json["marketSentiment"] ?? "NEUTRAL",
      marketRegime: json["marketRegime"] ?? "RANGING",

      fearGreed: json["fearGreed"] ?? "Neutral",
      volatility: json["volatility"] ?? "Low",

      currentSignal: json["currentSignal"] ?? "WAIT",
      confidence: (json["confidence"] ?? 0).toDouble(),

      todayPnL: (json["todayPnL"] ?? 0).toDouble(),

      totalTrades: json["totalTrades"] ?? 0,
      openTrades: json["openTrades"] ?? 0,

      winRate: (json["winRate"] ?? 0).toDouble(),

      activeStrategy: json["activeStrategy"] ?? "N/A",
      strategyVersion: json["strategyVersion"] ?? 1,

      schedulerRunning: json["schedulerRunning"] ?? false,

      lastLearning: json["lastLearning"] ?? "",

      lastUpdated: json["lastUpdated"] != null
          ? DateTime.parse(json["lastUpdated"])
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "btcPrice": btcPrice,
      "btcChange": btcChange,
      "ethPrice": ethPrice,
      "ethChange": ethChange,
      "marketSentiment": marketSentiment,
      "marketRegime": marketRegime,
      "fearGreed": fearGreed,
      "volatility": volatility,
      "currentSignal": currentSignal,
      "confidence": confidence,
      "todayPnL": todayPnL,
      "totalTrades": totalTrades,
      "openTrades": openTrades,
      "winRate": winRate,
      "activeStrategy": activeStrategy,
      "strategyVersion": strategyVersion,
      "schedulerRunning": schedulerRunning,
      "lastLearning": lastLearning,
      "lastUpdated": lastUpdated.toIso8601String(),
    };
  }

  DashboardModel copyWith({
    double? btcPrice,
    double? btcChange,
    double? ethPrice,
    double? ethChange,
    String? marketSentiment,
    String? marketRegime,
    String? fearGreed,
    String? volatility,
    String? currentSignal,
    double? confidence,
    double? todayPnL,
    int? totalTrades,
    int? openTrades,
    double? winRate,
    String? activeStrategy,
    int? strategyVersion,
    bool? schedulerRunning,
    String? lastLearning,
    DateTime? lastUpdated,
  }) {
    return DashboardModel(
      btcPrice: btcPrice ?? this.btcPrice,
      btcChange: btcChange ?? this.btcChange,
      ethPrice: ethPrice ?? this.ethPrice,
      ethChange: ethChange ?? this.ethChange,
      marketSentiment: marketSentiment ?? this.marketSentiment,
      marketRegime: marketRegime ?? this.marketRegime,
      fearGreed: fearGreed ?? this.fearGreed,
      volatility: volatility ?? this.volatility,
      currentSignal: currentSignal ?? this.currentSignal,
      confidence: confidence ?? this.confidence,
      todayPnL: todayPnL ?? this.todayPnL,
      totalTrades: totalTrades ?? this.totalTrades,
      openTrades: openTrades ?? this.openTrades,
      winRate: winRate ?? this.winRate,
      activeStrategy: activeStrategy ?? this.activeStrategy,
      strategyVersion: strategyVersion ?? this.strategyVersion,
      schedulerRunning:
          schedulerRunning ?? this.schedulerRunning,
      lastLearning: lastLearning ?? this.lastLearning,
      lastUpdated: lastUpdated ?? this.lastUpdated,
    );
  }

  @override
  String toString() {
    return '''
DashboardModel(
  Signal: $currentSignal
  Confidence: $confidence
  BTC: $btcPrice
  ETH: $ethPrice
  PnL: $todayPnL
  WinRate: $winRate
  Strategy: $activeStrategy
)
''';
  }
}