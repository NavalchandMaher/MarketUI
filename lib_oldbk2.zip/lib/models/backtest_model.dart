class BacktestModel {
  //==================================================
  // Identity
  //==================================================

  final String id;

  final String strategyName;

  final int strategyVersion;

  //==================================================
  // Market
  //==================================================

  final String symbol;

  final String timeframe;

  final int days;

  //==================================================
  // Trade Statistics
  //==================================================

  final int totalTrades;

  final int wins;

  final int losses;

  final int breakeven;

  //==================================================
  // Performance
  //==================================================

  final double winRate;

  final double lossRate;

  final double grossProfit;

  final double grossLoss;

  final double netProfit;

  final double averageProfit;

  final double averageLoss;

  final double expectancy;

  //==================================================
  // Risk Metrics
  //==================================================

  final double profitFactor;

  final double sharpeRatio;

  final double sortinoRatio;

  final double maxDrawdown;

  final double recoveryFactor;

  final double calmarRatio;

  //==================================================
  // AI Metrics
  //==================================================

  final double averageConfidence;

  final double bestConfidence;

  final double worstConfidence;

  //==================================================
  // Trade Duration
  //==================================================

  final double averageHoldingMinutes;

  final double longestTradeMinutes;

  final double shortestTradeMinutes;

  //==================================================
  // Strategy Evaluation
  //==================================================

  final String grade;

  final bool passed;

  final String remarks;

  //==================================================
  // Metadata
  //==================================================

  final DateTime createdAt;

  const BacktestModel({
    required this.id,
    required this.strategyName,
    required this.strategyVersion,
    required this.symbol,
    required this.timeframe,
    required this.days,
    required this.totalTrades,
    required this.wins,
    required this.losses,
    required this.breakeven,
    required this.winRate,
    required this.lossRate,
    required this.grossProfit,
    required this.grossLoss,
    required this.netProfit,
    required this.averageProfit,
    required this.averageLoss,
    required this.expectancy,
    required this.profitFactor,
    required this.sharpeRatio,
    required this.sortinoRatio,
    required this.maxDrawdown,
    required this.recoveryFactor,
    required this.calmarRatio,
    required this.averageConfidence,
    required this.bestConfidence,
    required this.worstConfidence,
    required this.averageHoldingMinutes,
    required this.longestTradeMinutes,
    required this.shortestTradeMinutes,
    required this.grade,
    required this.passed,
    required this.remarks,
    required this.createdAt,
  });

  factory BacktestModel.empty() {
    return BacktestModel(
      id: "",
      strategyName: "",
      strategyVersion: 1,
      symbol: "",
      timeframe: "",
      days: 30,
      totalTrades: 0,
      wins: 0,
      losses: 0,
      breakeven: 0,
      winRate: 0,
      lossRate: 0,
      grossProfit: 0,
      grossLoss: 0,
      netProfit: 0,
      averageProfit: 0,
      averageLoss: 0,
      expectancy: 0,
      profitFactor: 0,
      sharpeRatio: 0,
      sortinoRatio: 0,
      maxDrawdown: 0,
      recoveryFactor: 0,
      calmarRatio: 0,
      averageConfidence: 0,
      bestConfidence: 0,
      worstConfidence: 0,
      averageHoldingMinutes: 0,
      longestTradeMinutes: 0,
      shortestTradeMinutes: 0,
      grade: "N/A",
      passed: false,
      remarks: "",
      createdAt: DateTime.now(),
    );
  }

  factory BacktestModel.fromJson(Map<String, dynamic> json) {
    return BacktestModel(
      id: json["_id"]?.toString() ?? "",
      strategyName: json["strategy_name"] ?? "",
      strategyVersion: json["strategy_version"] ?? 1,
      symbol: json["symbol"] ?? "",
      timeframe: json["timeframe"] ?? "",
      days: json["days"] ?? 30,
      totalTrades: json["total_trades"] ?? 0,
      wins: json["wins"] ?? 0,
      losses: json["losses"] ?? 0,
      breakeven: json["breakeven"] ?? 0,
      winRate: (json["win_rate"] ?? 0).toDouble(),
      lossRate: (json["loss_rate"] ?? 0).toDouble(),
      grossProfit: (json["gross_profit"] ?? 0).toDouble(),
      grossLoss: (json["gross_loss"] ?? 0).toDouble(),
      netProfit: (json["net_profit"] ?? 0).toDouble(),
      averageProfit: (json["average_profit"] ?? 0).toDouble(),
      averageLoss: (json["average_loss"] ?? 0).toDouble(),
      expectancy: (json["expectancy"] ?? 0).toDouble(),
      profitFactor: (json["profit_factor"] ?? 0).toDouble(),
      sharpeRatio: (json["sharpe_ratio"] ?? 0).toDouble(),
      sortinoRatio: (json["sortino_ratio"] ?? 0).toDouble(),
      maxDrawdown: (json["drawdown"] ?? 0).toDouble(),
      recoveryFactor: (json["recovery_factor"] ?? 0).toDouble(),
      calmarRatio: (json["calmar_ratio"] ?? 0).toDouble(),
      averageConfidence: (json["average_confidence"] ?? 0).toDouble(),
      bestConfidence: (json["best_confidence"] ?? 0).toDouble(),
      worstConfidence: (json["worst_confidence"] ?? 0).toDouble(),
      averageHoldingMinutes:
          (json["average_holding_minutes"] ?? 0).toDouble(),
      longestTradeMinutes:
          (json["longest_trade_minutes"] ?? 0).toDouble(),
      shortestTradeMinutes:
          (json["shortest_trade_minutes"] ?? 0).toDouble(),
      grade: json["grade"] ?? "N/A",
      passed: json["passed"] ?? false,
      remarks: json["remarks"] ?? "",
      createdAt: json["created_at"] != null
          ? DateTime.parse(json["created_at"])
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() => {
        "_id": id,
        "strategy_name": strategyName,
        "strategy_version": strategyVersion,
        "symbol": symbol,
        "timeframe": timeframe,
        "days": days,
        "total_trades": totalTrades,
        "wins": wins,
        "losses": losses,
        "breakeven": breakeven,
        "win_rate": winRate,
        "loss_rate": lossRate,
        "gross_profit": grossProfit,
        "gross_loss": grossLoss,
        "net_profit": netProfit,
        "average_profit": averageProfit,
        "average_loss": averageLoss,
        "expectancy": expectancy,
        "profit_factor": profitFactor,
        "sharpe_ratio": sharpeRatio,
        "sortino_ratio": sortinoRatio,
        "drawdown": maxDrawdown,
        "recovery_factor": recoveryFactor,
        "calmar_ratio": calmarRatio,
        "average_confidence": averageConfidence,
        "best_confidence": bestConfidence,
        "worst_confidence": worstConfidence,
        "average_holding_minutes": averageHoldingMinutes,
        "longest_trade_minutes": longestTradeMinutes,
        "shortest_trade_minutes": shortestTradeMinutes,
        "grade": grade,
        "passed": passed,
        "remarks": remarks,
        "created_at": createdAt.toIso8601String(),
      };

  BacktestModel copyWith({
    String? id,
    String? strategyName,
    int? strategyVersion,
    String? symbol,
    String? timeframe,
    int? days,
    int? totalTrades,
    int? wins,
    int? losses,
    int? breakeven,
    double? winRate,
    double? lossRate,
    double? grossProfit,
    double? grossLoss,
    double? netProfit,
    double? averageProfit,
    double? averageLoss,
    double? expectancy,
    double? profitFactor,
    double? sharpeRatio,
    double? sortinoRatio,
    double? maxDrawdown,
    double? recoveryFactor,
    double? calmarRatio,
    double? averageConfidence,
    double? bestConfidence,
    double? worstConfidence,
    double? averageHoldingMinutes,
    double? longestTradeMinutes,
    double? shortestTradeMinutes,
    String? grade,
    bool? passed,
    String? remarks,
    DateTime? createdAt,
  }) {
    return BacktestModel(
      id: id ?? this.id,
      strategyName: strategyName ?? this.strategyName,
      strategyVersion: strategyVersion ?? this.strategyVersion,
      symbol: symbol ?? this.symbol,
      timeframe: timeframe ?? this.timeframe,
      days: days ?? this.days,
      totalTrades: totalTrades ?? this.totalTrades,
      wins: wins ?? this.wins,
      losses: losses ?? this.losses,
      breakeven: breakeven ?? this.breakeven,
      winRate: winRate ?? this.winRate,
      lossRate: lossRate ?? this.lossRate,
      grossProfit: grossProfit ?? this.grossProfit,
      grossLoss: grossLoss ?? this.grossLoss,
      netProfit: netProfit ?? this.netProfit,
      averageProfit: averageProfit ?? this.averageProfit,
      averageLoss: averageLoss ?? this.averageLoss,
      expectancy: expectancy ?? this.expectancy,
      profitFactor: profitFactor ?? this.profitFactor,
      sharpeRatio: sharpeRatio ?? this.sharpeRatio,
      sortinoRatio: sortinoRatio ?? this.sortinoRatio,
      maxDrawdown: maxDrawdown ?? this.maxDrawdown,
      recoveryFactor: recoveryFactor ?? this.recoveryFactor,
      calmarRatio: calmarRatio ?? this.calmarRatio,
      averageConfidence:
          averageConfidence ?? this.averageConfidence,
      bestConfidence: bestConfidence ?? this.bestConfidence,
      worstConfidence: worstConfidence ?? this.worstConfidence,
      averageHoldingMinutes:
          averageHoldingMinutes ?? this.averageHoldingMinutes,
      longestTradeMinutes:
          longestTradeMinutes ?? this.longestTradeMinutes,
      shortestTradeMinutes:
          shortestTradeMinutes ?? this.shortestTradeMinutes,
      grade: grade ?? this.grade,
      passed: passed ?? this.passed,
      remarks: remarks ?? this.remarks,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  bool get isProfitable => netProfit > 0;
  bool get isExcellent => profitFactor >= 2.0;
  bool get isPassed => passed;

  @override
  String toString() {
    return '''
BacktestModel(
  strategy: $strategyName
  profitFactor: $profitFactor
  netProfit: $netProfit
  winRate: $winRate
  grade: $grade
)
''';
  }
}