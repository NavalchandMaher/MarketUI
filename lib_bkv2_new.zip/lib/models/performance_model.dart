
class PerformanceModel{
  final int totalTrades,wins,losses;
  final double winRate,netProfit;
  const PerformanceModel({required this.totalTrades,required this.wins,required this.losses,required this.winRate,required this.netProfit});
}
