
class LearningLogModel{
  final String action,date;
  final double winRate;
  const LearningLogModel({required this.action,required this.date,required this.winRate});
}
