
class SchedulerModel{
  final bool running;
  final String nextRun;
  const SchedulerModel({required this.running,required this.nextRun});
}
