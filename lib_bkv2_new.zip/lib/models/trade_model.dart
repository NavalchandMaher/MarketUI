
class TradeModel{
  final String id,symbol,signal,status;
  final double entryPrice,exitPrice,pnl;
  const TradeModel({required this.id,required this.symbol,required this.signal,required this.status,required this.entryPrice,required this.exitPrice,required this.pnl});
}
