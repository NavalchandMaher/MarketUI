
class ReportModel{
  final String title,date;
  const ReportModel({required this.title,required this.date});
}
