
class BacktestModel{
  final String strategy;
  final double profitFactor,netProfit,winRate;
  const BacktestModel({required this.strategy,required this.profitFactor,required this.netProfit,required this.winRate});
}
