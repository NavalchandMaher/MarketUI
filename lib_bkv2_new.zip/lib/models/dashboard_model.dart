
class DashboardModel {
  final double btcPrice, btcChange, ethPrice, ethChange, confidence, todayPnL, winRate;
  final int totalTrades, openTrades, strategyVersion;
  final String currentSignal, marketSentiment, marketRegime, fearGreed,
      volatility, activeStrategy, lastLearning;
  final bool schedulerRunning;
  final DateTime lastUpdated;

  const DashboardModel({
    required this.btcPrice,
    required this.btcChange,
    required this.ethPrice,
    required this.ethChange,
    required this.confidence,
    required this.todayPnL,
    required this.winRate,
    required this.totalTrades,
    required this.openTrades,
    required this.strategyVersion,
    required this.currentSignal,
    required this.marketSentiment,
    required this.marketRegime,
    required this.fearGreed,
    required this.volatility,
    required this.activeStrategy,
    required this.lastLearning,
    required this.schedulerRunning,
    required this.lastUpdated,
  });
}
