
class StrategyModel{
  final String name;
  final int version;
  final bool enabled;
  const StrategyModel({required this.name,required this.version,required this.enabled});
}
