
class AnalysisModel{
  final String signal,symbol,timeframe;
  final double price,confidence;
  const AnalysisModel({required this.signal,required this.symbol,required this.timeframe,required this.price,required this.confidence});
}
