
import 'package:flutter/foundation.dart';
import '../../models/dashboard_model.dart';
import 'dashboard_controller.dart';

class DashboardProvider extends ChangeNotifier{
  final DashboardController controller=DashboardController();

  DashboardModel? dashboard;
  bool loading=false;
  String? error;

  Future<void> refresh() async{
    loading=true;
    error=null;
    notifyListeners();
    try{
      dashboard=await controller.loadDashboard();
    }catch(e){
      error=e.toString();
    }
    loading=false;
    notifyListeners();
  }
}
