
import '../../models/dashboard_model.dart';
import '../../services/dashboard_service.dart';

class DashboardController{
  Future<DashboardModel> loadDashboard() async{
    return DashboardService.loadDashboard();
  }
}
