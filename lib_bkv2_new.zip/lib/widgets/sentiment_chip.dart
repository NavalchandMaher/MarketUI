
import 'package:flutter/material.dart';

class SentimentChip extends StatelessWidget {
  final String sentiment;
  final bool compact;

  const SentimentChip({
    super.key,
    required this.sentiment,
    this.compact = false,
  });

  Color get _color {
    switch (sentiment.toUpperCase()) {
      case 'STRONG BULLISH':
      case 'BULLISH':
        return Colors.green;
      case 'STRONG BEARISH':
      case 'BEARISH':
        return Colors.red;
      case 'NEUTRAL':
        return Colors.orange;
      default:
        return Colors.blueGrey;
    }
  }

  IconData get _icon {
    switch (sentiment.toUpperCase()) {
      case 'STRONG BULLISH':
      case 'BULLISH':
        return Icons.trending_up;
      case 'STRONG BEARISH':
      case 'BEARISH':
        return Icons.trending_down;
      case 'NEUTRAL':
        return Icons.remove;
      default:
        return Icons.analytics;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Chip(
      avatar: Icon(
        _icon,
        color: _color,
        size: compact ? 16 : 20,
      ),
      label: Text(
        sentiment,
        style: TextStyle(
          color: _color,
          fontWeight: FontWeight.bold,
          fontSize: compact ? 12 : 14,
        ),
      ),
      backgroundColor: _color.withOpacity(0.12),
      side: BorderSide(color: _color),
      padding: EdgeInsets.symmetric(
        horizontal: compact ? 6 : 10,
        vertical: compact ? 2 : 6,
      ),
    );
  }
}
