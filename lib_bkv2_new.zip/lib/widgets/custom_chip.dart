
import 'package:flutter/material.dart';

class CustomChip extends StatelessWidget{
 final String label;
 final Color color;
 const CustomChip({super.key,required this.label,this.color=Colors.blue});
 @override
 Widget build(BuildContext context){
  return Chip(label:Text(label),backgroundColor:color.withOpacity(.15));
 }
}
