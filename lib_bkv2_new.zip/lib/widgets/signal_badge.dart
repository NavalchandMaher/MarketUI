
import 'package:flutter/material.dart';

class SignalBadge extends StatelessWidget {
  final String signal;
  final bool large;

  const SignalBadge({
    super.key,
    required this.signal,
    this.large = false,
  });

  Color get _color {
    switch (signal.toUpperCase()) {
      case 'BUY':
        return Colors.green;
      case 'SELL':
        return Colors.red;
      case 'WAIT':
        return Colors.orange;
      default:
        return Colors.grey;
    }
  }

  IconData get _icon {
    switch (signal.toUpperCase()) {
      case 'BUY':
        return Icons.trending_up;
      case 'SELL':
        return Icons.trending_down;
      case 'WAIT':
        return Icons.pause_circle;
      default:
        return Icons.help_outline;
    }
  }

  @override
  Widget build(BuildContext context) {
    final pad = large ? 18.0 : 10.0;

    return Container(
      padding: EdgeInsets.symmetric(horizontal: pad, vertical: pad / 2),
      decoration: BoxDecoration(
        color: _color.withOpacity(.12),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: _color, width: 1.5),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            _icon,
            color: _color,
            size: large ? 24 : 18,
          ),
          const SizedBox(width: 8),
          Text(
            signal.toUpperCase(),
            style: TextStyle(
              color: _color,
              fontWeight: FontWeight.bold,
              fontSize: large ? 20 : 14,
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }
}
