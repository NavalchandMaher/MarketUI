
import 'package:flutter/material.dart';

class QuickActionsCard extends StatelessWidget{
 const QuickActionsCard({super.key});
 @override
 Widget build(BuildContext context){
  return const Card(
    child:SizedBox(height:180,child:Center(child:Text('quick_actions_card.dart placeholder'))),
  );
 }
}
