
import 'package:flutter/material.dart';

class SummaryCard extends StatelessWidget{
 final String title,value;
 final IconData icon;
 const SummaryCard({super.key,required this.title,required this.value,required this.icon});
 @override
 Widget build(BuildContext context){
  return Card(
   child:Padding(
    padding:const EdgeInsets.all(16),
    child:Column(
      children:[
        Icon(icon,size:32),
        const SizedBox(height:10),
        Text(value,style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold)),
        Text(title),
      ],
    ),
   ),
  );
 }
}
