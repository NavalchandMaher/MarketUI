
import 'package:flutter/material.dart';

class StrategyCard extends StatelessWidget{
 const StrategyCard({super.key});
 @override
 Widget build(BuildContext context){
  return const Card(
    child:SizedBox(height:180,child:Center(child:Text('strategy_card.dart placeholder'))),
  );
 }
}
