
import 'package:flutter/material.dart';

class SignalCard extends StatelessWidget{
 const SignalCard({super.key});
 @override
 Widget build(BuildContext context){
  return const Card(
    child:SizedBox(height:180,child:Center(child:Text('signal_card.dart placeholder'))),
  );
 }
}
