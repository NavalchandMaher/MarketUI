
import 'package:flutter/material.dart';

class SchedulerCard extends StatelessWidget{
 const SchedulerCard({super.key});
 @override
 Widget build(BuildContext context){
  return const Card(
    child:SizedBox(height:180,child:Center(child:Text('scheduler_card.dart placeholder'))),
  );
 }
}
