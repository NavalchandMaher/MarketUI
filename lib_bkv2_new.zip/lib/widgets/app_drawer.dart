
import 'package:flutter/material.dart';

class AppDrawer extends StatelessWidget{
  final ValueChanged<int>? onItemSelected;
  const AppDrawer({super.key,this.onItemSelected});

  @override
  Widget build(BuildContext context){
    final items=[
      'Dashboard','Paper Trading','Trade History','Performance',
      'Learning Logs','Backtesting','Strategy','Reports','Settings'
    ];
    return Drawer(
      child: ListView(
        children:[
          const DrawerHeader(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children:[
                Icon(Icons.show_chart,size:48),
                SizedBox(height:12),
                Text('Market AI V2',
                  style: TextStyle(fontSize:22,fontWeight:FontWeight.bold)),
              ],
            ),
          ),
          ...List.generate(items.length,(i)=>ListTile(
            title: Text(items[i]),
            onTap: ()=>onItemSelected?.call(i),
          ))
        ],
      ),
    );
  }
}
