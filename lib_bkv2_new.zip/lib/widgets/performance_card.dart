
import 'package:flutter/material.dart';

class PerformanceCard extends StatelessWidget{
 const PerformanceCard({super.key});
 @override
 Widget build(BuildContext context){
  return const Card(
    child:SizedBox(height:180,child:Center(child:Text('performance_card.dart placeholder'))),
  );
 }
}
