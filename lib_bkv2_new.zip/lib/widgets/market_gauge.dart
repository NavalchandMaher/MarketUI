
import 'package:flutter/material.dart';

class MarketGauge extends StatelessWidget {
  final double value; // 0-100
  final String label;

  const MarketGauge({
    super.key,
    required this.value,
    this.label = "Market Strength",
  });

  Color get _color {
    if (value >= 70) return Colors.green;
    if (value >= 40) return Colors.orange;
    return Colors.red;
  }

  String get _status {
    if (value >= 70) return "Bullish";
    if (value >= 40) return "Neutral";
    return "Bearish";
  }

  @override
  Widget build(BuildContext context) {
    final v = value.clamp(0, 100);

    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text(
              label,
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: 150,
              height: 150,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  CircularProgressIndicator(
                    value: v / 100,
                    strokeWidth: 12,
                    backgroundColor: Colors.grey.shade300,
                    valueColor: AlwaysStoppedAnimation(_color),
                  ),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        "${v.toStringAsFixed(0)}%",
                        style: const TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        _status,
                        style: TextStyle(
                          color: _color,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            LinearProgressIndicator(
              value: v / 100,
              minHeight: 8,
              borderRadius: BorderRadius.circular(8),
              valueColor: AlwaysStoppedAnimation(_color),
            ),
          ],
        ),
      ),
    );
  }
}
