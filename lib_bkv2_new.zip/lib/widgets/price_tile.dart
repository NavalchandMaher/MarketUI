
import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

class PriceTile extends StatelessWidget {
  final String symbol;
  final double price;
  final double changePercent;
  final String? exchange;
  final IconData? icon;
  final VoidCallback? onTap;

  const PriceTile({
    super.key,
    required this.symbol,
    required this.price,
    required this.changePercent,
    this.exchange,
    this.icon,
    this.onTap,
  });

  bool get _isPositive => changePercent >= 0;

  @override
  Widget build(BuildContext context) {
    final color = _isPositive ? Colors.green : Colors.red;

    return Card(
      elevation: 1,
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              CircleAvatar(
                backgroundColor: AppTheme.primary.withOpacity(.12),
                child: Icon(
                  icon ?? Icons.currency_bitcoin,
                  color: AppTheme.primary,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      symbol,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    if (exchange != null)
                      Text(
                        exchange!,
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    "\$${price.toStringAsFixed(2)}",
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: color.withOpacity(.12),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          _isPositive
                              ? Icons.arrow_upward
                              : Icons.arrow_downward,
                          color: color,
                          size: 14,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          "${_isPositive ? "+" : ""}${changePercent.toStringAsFixed(2)}%",
                          style: TextStyle(
                            color: color,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
