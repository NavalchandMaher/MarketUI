
import 'package:flutter/material.dart';

import '../models/dashboard_model.dart';
import '../theme/app_theme.dart';

class MarketCard extends StatelessWidget {
  final DashboardModel dashboard;
  final bool loading;

  const MarketCard({
    super.key,
    required this.dashboard,
    this.loading = false,
  });

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Card(
        child: SizedBox(
          height: 260,
          child: Center(child: CircularProgressIndicator()),
        ),
      );
    }

    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.show_chart, color: AppTheme.primary),
                const SizedBox(width: 8),
                Text(
                  'Market Overview',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
              ],
            ),
            const SizedBox(height: 20),
            _priceTile(
              "BTC",
              dashboard.btcPrice,
              dashboard.btcChange,
            ),
            const SizedBox(height: 12),
            _priceTile(
              "ETH",
              dashboard.ethPrice,
              dashboard.ethChange,
            ),
            const Divider(height: 28),
            _infoRow("Market Sentiment", dashboard.marketSentiment),
            _infoRow("Market Regime", dashboard.marketRegime),
            _infoRow("Fear & Greed", dashboard.fearGreed),
            _infoRow("Volatility", dashboard.volatility),
            const SizedBox(height: 20),
            LinearProgressIndicator(
              value: _sentimentValue(dashboard.marketSentiment),
              minHeight: 10,
              borderRadius: BorderRadius.circular(10),
            ),
          ],
        ),
      ),
    );
  }

  Widget _priceTile(String symbol, double price, double change) {
    final up = change >= 0;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.darkCard,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          CircleAvatar(child: Text(symbol.substring(0,1))),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              symbol,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                "\$${price.toStringAsFixed(2)}",
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
              ),
              Text(
                "${up ? "+" : ""}${change.toStringAsFixed(2)}%",
                style: TextStyle(
                  color: up ? Colors.green : Colors.red,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _infoRow(String title, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(child: Text(title)),
          Text(
            value,
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  double _sentimentValue(String sentiment) {
    switch (sentiment.toUpperCase()) {
      case "BULLISH":
        return 1.0;
      case "NEUTRAL":
        return 0.5;
      case "BEARISH":
        return 0.2;
      default:
        return 0.5;
    }
  }
}
