
import 'package:flutter/material.dart';

class PnlChart extends StatelessWidget{
 const PnlChart({super.key});
 @override
 Widget build(BuildContext context){
  return const Card(
    child:SizedBox(
      height:220,
      child:Center(child:Text('P&L Chart Placeholder')),
    ),
  );
 }
}
