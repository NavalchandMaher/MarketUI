
import 'package:flutter/material.dart';

import '../models/dashboard_model.dart';
import '../theme/app_theme.dart';

class MarketHeader extends StatelessWidget {
  final DashboardModel dashboard;
  final VoidCallback? onRefresh;

  const MarketHeader({
    super.key,
    required this.dashboard,
    this.onRefresh,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.darkCard,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          const Icon(
            Icons.show_chart,
            color: AppTheme.primary,
            size: 32,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Market AI V2",
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 4),
                Text(
                  "Live Market Dashboard",
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Chip(
                avatar: Icon(
                  Icons.circle,
                  color: dashboard.schedulerRunning
                      ? Colors.green
                      : Colors.red,
                  size: 12,
                ),
                label: Text(
                  dashboard.schedulerRunning
                      ? "Scheduler ON"
                      : "Scheduler OFF",
                ),
              ),
              const SizedBox(height: 8),
              Text(
                "Updated: "
                "${dashboard.lastUpdated.hour.toString().padLeft(2, '0')}:"
                "${dashboard.lastUpdated.minute.toString().padLeft(2, '0')}",
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ),
          const SizedBox(width: 8),
          IconButton(
            tooltip: "Refresh",
            onPressed: onRefresh,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
    );
  }
}
