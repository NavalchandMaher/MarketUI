
import 'package:flutter/material.dart';

class LearningCard extends StatelessWidget{
 const LearningCard({super.key});
 @override
 Widget build(BuildContext context){
  return const Card(
    child:SizedBox(height:180,child:Center(child:Text('learning_card.dart placeholder'))),
  );
 }
}
