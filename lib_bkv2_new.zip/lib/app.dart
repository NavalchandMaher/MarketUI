
import 'package:flutter/material.dart';
import 'theme/app_theme.dart';

class MarketAIApp extends StatelessWidget {
  const MarketAIApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Market AI V2',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: ThemeMode.dark,
      home: const Scaffold(
        body: Center(child: Text('Dashboard Screen Placeholder')),
      ),
    );
  }
}
