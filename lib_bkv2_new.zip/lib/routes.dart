
class AppRoutes {
  static const dashboard='/';
  static const paperTrading='/paper-trading';
  static const performance='/performance';
  static const settings='/settings';
}
