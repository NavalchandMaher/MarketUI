
import 'package:http/http.dart' as http;

class ApiService {
  static const String baseUrl = 'http://10.0.2.2:8000';

  static Future<http.Response> get(String endpoint) {
    return http.get(Uri.parse('$baseUrl$endpoint'));
  }

  static Future<http.Response> post(String endpoint) {
    return http.post(Uri.parse('$baseUrl$endpoint'));
  }
}
