
import 'dart:convert';
import 'api_service.dart';

class PaperTradeService{
 static Future<Map<String,dynamic>> dashboard() async{
   final r=await ApiService.get('/paper-trades');
   return jsonDecode(r.body);
 }
 static Future<List<dynamic>> history() async{
   final r=await ApiService.get('/paper-trades/history');
   return jsonDecode(r.body);
 }
}
