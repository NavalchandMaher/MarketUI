
import 'dart:convert';
import 'api_service.dart';

class SchedulerService{
 static Future<Map<String,dynamic>> status() async{
   final r=await ApiService.get('/scheduler/status');
   return jsonDecode(r.body);
 }
 static Future<void> runMarket() async{
   await ApiService.post('/scheduler/run-market');
 }
 static Future<void> runNightly() async{
   await ApiService.post('/scheduler/run-nightly');
 }
}
