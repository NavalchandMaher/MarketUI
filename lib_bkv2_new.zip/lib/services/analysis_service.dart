
import 'dart:convert';
import 'api_service.dart';

class AnalysisService{
  static Future<Map<String,dynamic>> analysis({
    String symbol='BTCUSDT',
    String timeframe='15m'
  }) async{
    final r=await ApiService.get('/analysis?symbol=$symbol&timeframe=$timeframe');
    return jsonDecode(r.body);
  }
}
