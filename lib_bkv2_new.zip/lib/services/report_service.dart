
class ReportService{
  const ReportService();
}
