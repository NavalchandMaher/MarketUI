
import 'dart:convert';
import 'api_service.dart';

class PerformanceService{
 static Future<Map<String,dynamic>> load() async{
   final r=await ApiService.get('/performance');
   return jsonDecode(r.body);
 }
}
