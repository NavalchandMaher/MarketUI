
import 'dart:convert';
import 'api_service.dart';

class StrategyService{
 static Future<Map<String,dynamic>> current() async{
   final r=await ApiService.get('/strategy');
   return jsonDecode(r.body);
 }
}
