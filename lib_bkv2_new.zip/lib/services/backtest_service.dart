
import 'dart:convert';
import 'api_service.dart';

class BacktestService{
 static Future<Map<String,dynamic>> run() async{
   final r=await ApiService.get('/backtest');
   return jsonDecode(r.body);
 }
 static Future<List<dynamic>> history() async{
   final r=await ApiService.get('/backtest/history');
   return jsonDecode(r.body);
 }
}
