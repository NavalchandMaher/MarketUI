
import 'dart:convert';
import 'api_service.dart';

class LearningService{
 static Future<List<dynamic>> logs() async{
   final r=await ApiService.get('/learning-logs');
   return jsonDecode(r.body);
 }
}
