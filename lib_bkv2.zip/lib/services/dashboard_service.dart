import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/dashboard_model.dart';
import 'api_service.dart';

class DashboardService {
  DashboardService._();

  static const Duration _timeout = Duration(seconds: 20);

  //==========================================================
  // Load Complete Dashboard
  //==========================================================

  static Future<DashboardModel> loadDashboard() async {
    try {
      final results = await Future.wait([
        _analysis(),
        _performance(),
        _paperTrades(),
        _strategy(),
        _scheduler(),
        _learningLogs(),
      ]);

      return buildDashboard(
        analysis: results[0],
        performance: results[1],
        paperTrades: results[2],
        strategy: results[3],
        scheduler: results[4],
        learning: results[5],
      );
    } catch (e) {
      throw Exception(
        "Unable to load dashboard : $e",
      );
    }
  }

  //==========================================================
  // Generic GET
  //==========================================================

  static Future<Map<String, dynamic>> _get(
    String endpoint,
  ) async {
    final response = await http
        .get(
          Uri.parse(
            "${ApiService.baseUrl}$endpoint",
          ),
          headers: {
            "Content-Type": "application/json",
            "Accept": "application/json",
          },
        )
        .timeout(_timeout);

    if (response.statusCode != 200) {
      throw Exception(
        "HTTP ${response.statusCode} : $endpoint",
      );
    }

    final data = jsonDecode(response.body);

    if (data is Map<String, dynamic>) {
      return data;
    }

    return {
      "data": data,
    };
  }

  //==========================================================
  // Dashboard APIs
  //==========================================================

  static Future<Map<String, dynamic>> _analysis() {
    return _get(
      "/analysis?symbol=BTCUSDT&timeframe=15m",
    );
  }

  static Future<Map<String, dynamic>> _performance() {
    return _get(
      "/performance",
    );
  }

  static Future<Map<String, dynamic>> _paperTrades() {
    return _get(
      "/paper-trades",
    );
  }
    static Future<Map<String, dynamic>> _strategy() {
    return _get(
      "/strategy",
    );
  }

  //==========================================================
  // Scheduler Status
  //==========================================================

  static Future<Map<String, dynamic>> _scheduler() {
    return _get(
      "/scheduler/status",
    );
  }

  //==========================================================
  // Learning Logs
  //==========================================================

  static Future<Map<String, dynamic>> _learningLogs() async {
    final response = await http
        .get(
          Uri.parse(
            "${ApiService.baseUrl}/learning-logs",
          ),
          headers: {
            "Content-Type": "application/json",
            "Accept": "application/json",
          },
        )
        .timeout(_timeout);

    if (response.statusCode != 200) {
      return {
        "logs": [],
      };
    }

    final data = jsonDecode(response.body);

    if (data is List) {
      return {
        "logs": data,
      };
    }

    return {
      "logs": [],
    };
  }

  //==========================================================
  // Backtest History
  //==========================================================

  static Future<List<dynamic>> backtestHistory() async {
    final response = await http
        .get(
          Uri.parse(
            "${ApiService.baseUrl}/backtest/history",
          ),
        )
        .timeout(_timeout);

    if (response.statusCode != 200) {
      return [];
    }

    final data = jsonDecode(response.body);

    if (data is List) {
      return data;
    }

    return [];
  }

  //==========================================================
  // Trade History
  //==========================================================

  static Future<List<dynamic>> tradeHistory({
    int limit = 100,
  }) async {
    final response = await http
        .get(
          Uri.parse(
            "${ApiService.baseUrl}/paper-trades/history?limit=$limit",
          ),
        )
        .timeout(_timeout);

    if (response.statusCode != 200) {
      return [];
    }

    final data = jsonDecode(response.body);

    if (data is List) {
      return data;
    }

    return [];
  }

  //==========================================================
  // Simple Logger
  //==========================================================

  static void log(
    String message,
  ) {
    final now = DateTime.now();

    print(
      "[DashboardService] "
      "${now.toIso8601String()} "
      "$message",
    );
  }
    //==========================================================
  // Safe String
  //==========================================================

  static String asString(
    dynamic value, {
    String defaultValue = "",
  }) {
    if (value == null) return defaultValue;

    return value.toString();
  }

  //==========================================================
  // Safe Double
  //==========================================================

  static double asDouble(
    dynamic value, {
    double defaultValue = 0,
  }) {
    if (value == null) return defaultValue;

    if (value is double) return value;

    if (value is int) return value.toDouble();

    return double.tryParse(value.toString()) ??
        defaultValue;
  }

  //==========================================================
  // Safe Integer
  //==========================================================

  static int asInt(
    dynamic value, {
    int defaultValue = 0,
  }) {
    if (value == null) return defaultValue;

    if (value is int) return value;

    return int.tryParse(value.toString()) ??
        defaultValue;
  }

  //==========================================================
  // Safe Bool
  //==========================================================

  static bool asBool(
    dynamic value, {
    bool defaultValue = false,
  }) {
    if (value == null) return defaultValue;

    if (value is bool) return value;

    return value.toString().toLowerCase() == "true";
  }

  //==========================================================
  // Parse Date
  //==========================================================

  static DateTime asDate(
    dynamic value,
  ) {
    if (value == null) {
      return DateTime.now();
    }

    try {
      return DateTime.parse(
        value.toString(),
      );
    } catch (_) {
      return DateTime.now();
    }
  }

  //==========================================================
  // Build Dashboard Model
  //==========================================================

  static DashboardModel buildDashboard({

    required Map<String, dynamic> analysis,

    required Map<String, dynamic> performance,

    required Map<String, dynamic> paperTrades,

    required Map<String, dynamic> strategy,

    required Map<String, dynamic> scheduler,

    required Map<String, dynamic> learning,

  }) {

    return DashboardModel(

      //---------------------------------------
      // Market
      //---------------------------------------

      btcPrice: asDouble(
        analysis["price"],
      ),

      btcChange: asDouble(
        analysis["price_change"],
      ),

      ethPrice: 0,

      ethChange: 0,

      //---------------------------------------
      // Signal
      //---------------------------------------

      currentSignal: asString(
        analysis["signal"],
        defaultValue: "WAIT",
      ),

      confidence: asDouble(
        analysis["confidence"],
      ),

      marketSentiment: asString(
        analysis["market_sentiment"],
        defaultValue: "NEUTRAL",
      ),

      marketRegime: asString(
        analysis["market_regime"],
        defaultValue: "RANGING",
      ),

      //---------------------------------------
      // Performance
      //---------------------------------------

      todayPnL: asDouble(
        performance["net_profit"],
      ),

      totalTrades: asInt(
        performance["total_trades"],
      ),

      winRate: asDouble(
        performance["win_rate"],
      ),

      //---------------------------------------
      // Paper Trading
      //---------------------------------------

      openTrades: asInt(
        paperTrades["open_trades"],
      ),

      //---------------------------------------
      // Strategy
      //---------------------------------------

      activeStrategy: asString(
        strategy["name"],
      ),

      strategyVersion: asInt(
        strategy["version"],
      ),

      //---------------------------------------
      // Scheduler
      //---------------------------------------

      schedulerRunning: asBool(
        scheduler["running"],
      ),

      //---------------------------------------
      // Learning
      //---------------------------------------

      lastLearning: learning["logs"] is List &&
              (learning["logs"] as List).isNotEmpty
          ? asString(
              learning["logs"][0]["date"],
            )
          : "",

      //---------------------------------------
      // Extra
      //---------------------------------------

      fearGreed: "Greed",

      volatility: "Medium",

      lastUpdated: DateTime.now(),

    );

  }

}