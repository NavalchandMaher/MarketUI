import 'dart:async';

import 'package:flutter/material.dart';
import 'package:market_app/models/dashboard_model.dart';

import '../../theme/app_theme.dart';

// Widgets (We'll create these next)
import '../../widgets/market_card.dart';
import '../../widgets/signal_card.dart';
import '../../widgets/performance_card.dart';
import '../../widgets/strategy_card.dart';
import '../../widgets/scheduler_card.dart';
import '../../widgets/quick_action_card.dart';
import '../../widgets/recent_trade_card.dart';

// Services (We'll create later)
import '../../services/dashboard_service.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {

  Timer? _timer;

  bool loading = true;

  DashboardModel dashboard = DashboardModel.empty();

  @override
  void initState() {
    super.initState();

    loadDashboard();

    startAutoRefresh();
  }

  @override
  void dispose() {
    _timer?.cancel();

    super.dispose();
  }

  //------------------------------------------------------------
  // Auto Refresh
  //------------------------------------------------------------

  void startAutoRefresh() {

    _timer = Timer.periodic(

      const Duration(seconds: 30),

      (_) {

        loadDashboard();

      },

    );

  }

  //------------------------------------------------------------
  // Load Dashboard
  //------------------------------------------------------------

  Future<void> loadDashboard() async {

    setState(() {

      loading = true;

    });

    try {

      dashboard = await DashboardService.loadDashboard();

    } catch (e) {

      debugPrint(e.toString());

    }

    if (!mounted) return;

    setState(() {

      loading = false;

    });

  }

  //------------------------------------------------------------
  // Pull To Refresh
  //------------------------------------------------------------

  Future<void> refreshDashboard() async {

    await loadDashboard();

  }

  //------------------------------------------------------------
  // Drawer Navigation
  //------------------------------------------------------------

  void navigate(String route) {

    Navigator.pop(context);

    Navigator.pushNamed(

      context,

      route,

    );
  }

    //------------------------------------------------------------
  // UI
  //------------------------------------------------------------

  @override
  Widget build(BuildContext context) {

    final size = MediaQuery.of(context).size;

    final isTablet = size.width >= 700;

    return Scaffold(

      backgroundColor: AppTheme.darkBackground,

      appBar: const DashboardAppBar(),

      drawer: DashboardNavigationDrawer(

        onNavigate: navigate,

      ),

      body: RefreshIndicator(

        color: AppTheme.primary,

        onRefresh: refreshDashboard,

        child: loading

            ? const Center(

                child: CircularProgressIndicator(),

              )

            : SafeArea(

                child: SingleChildScrollView(

                  physics: const AlwaysScrollableScrollPhysics(),

                  padding: const EdgeInsets.all(16),

                  child: Column(

                    crossAxisAlignment: CrossAxisAlignment.start,

                    children: [

                      //------------------------------------------
                      // Header
                      //------------------------------------------

                      Text(

                        "Market AI Dashboard",

                        style: Theme.of(context)
                            .textTheme
                            .headlineSmall,

                      ),

                      const SizedBox(height: 6),

                      Text(

                        "Real-Time AI Trading Assistant",

                        style: Theme.of(context)
                            .textTheme
                            .bodyMedium
                            ?.copyWith(

                              color: Colors.white60,

                            ),

                      ),

                      const SizedBox(height: 20),

                      //------------------------------------------
                      // Responsive Layout
                      //------------------------------------------

                      if (isTablet)

                        _buildTabletLayout()

                      else

                        _buildMobileLayout(),

                    ],

                  ),

                ),

              ),

      ),

      floatingActionButton: FloatingActionButton(

        onPressed: loadDashboard,

        child: const Icon(Icons.refresh),

      ),

      bottomNavigationBar: NavigationBar(

        selectedIndex: 0,

        onDestinationSelected: (index) {

          switch (index) {

            case 0:
              break;

            case 1:
              Navigator.pushNamed(
                context,
                "/paper-trades",
              );
              break;

            case 2:
              Navigator.pushNamed(
                context,
                "/analysis",
              );
              break;

            case 3:
              Navigator.pushNamed(
                context,
                "/performance",
              );
              break;

            case 4:
              Navigator.pushNamed(
                context,
                "/settings",
              );
              break;

          }

        },

        destinations: const [

          NavigationDestination(
            icon: Icon(Icons.dashboard),
            label: "Dashboard",
          ),

          NavigationDestination(
            icon: Icon(Icons.currency_exchange),
            label: "Trades",
          ),

          NavigationDestination(
            icon: Icon(Icons.auto_graph),
            label: "Analysis",
          ),

          NavigationDestination(
            icon: Icon(Icons.bar_chart),
            label: "Performance",
          ),

          NavigationDestination(
            icon: Icon(Icons.settings),
            label: "Settings",
          ),

        ],

      ),

    );

  }
    //==========================================================
  // Mobile Layout
  //==========================================================

  Widget _buildMobileLayout() {
    return Column(
      children: [
        const MarketCard()

        const SizedBox(height: 16),

        const SignalCard(),

        const SizedBox(height: 16),

        const PerformanceCard(),

        const SizedBox(height: 16),

        const StrategyCard(),

        const SizedBox(height: 16),

        const SchedulerCard(),

        const SizedBox(height: 20),

        const QuickActionCard(),

        const SizedBox(height: 20),

        Align(
          alignment: Alignment.centerLeft,
          child: Text(
            "Recent Trades",
            style: Theme.of(context).textTheme.titleLarge,
          ),
        ),

        const SizedBox(height: 10),

        const RecentTradeCard(),

        const SizedBox(height: 20),
      ],
    );
  }

  //==========================================================
  // Tablet/Desktop Layout
  //==========================================================

  Widget _buildTabletLayout() {
    return Column(
      children: [

        //---------------------------------------
        // First Row
        //---------------------------------------

        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            Expanded(
              child: const MarketSummaryCard(),
            ),

            const SizedBox(width: 16),

            Expanded(
              child: const SignalCard(),
            ),

          ],
        ),

        const SizedBox(height: 16),

        //---------------------------------------
        // Second Row
        //---------------------------------------

        Row(
          children: [

            Expanded(
              child: const PerformanceCard(),
            ),

            const SizedBox(width: 16),

            Expanded(
              child: const StrategyCard(),
            ),

          ],
        ),

        const SizedBox(height: 16),

        //---------------------------------------
        // Scheduler
        //---------------------------------------

        const SchedulerCard(),

        const SizedBox(height: 20),

        //---------------------------------------
        // Quick Actions
        //---------------------------------------

        const QuickActions(),

        const SizedBox(height: 20),

        //---------------------------------------
        // Recent Trades
        //---------------------------------------

        Align(
          alignment: Alignment.centerLeft,
          child: Text(
            "Recent Trades",
            style: Theme.of(context).textTheme.titleLarge,
          ),
        ),

        const SizedBox(height: 10),

        const RecentTradeCard(),

        const SizedBox(height: 20),

      ],
    );
  }
}