import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'theme/app_theme.dart';
import 'screens/dashboard/dashboard_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Lock portrait mode (change if tablet support is needed)
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
  ]);

  // Transparent status bar
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarBrightness: Brightness.dark,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Color(0xff121212),
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );

  runApp(const MarketAIApp());
}

class MarketAIApp extends StatelessWidget {
  const MarketAIApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Market AI V2",
      debugShowCheckedModeBanner: false,

      themeMode: ThemeMode.dark,

      theme: AppTheme.lightTheme,

      darkTheme: AppTheme.darkTheme,

      home: const DashboardScreen(),

      routes: {
        "/dashboard": (_) => const DashboardScreen(),

        // Next Phases
        // "/signal": (_) => SignalScreen(),
        // "/paper": (_) => PaperTradingScreen(),
        // "/history": (_) => TradeHistoryScreen(),
        // "/performance": (_) => PerformanceScreen(),
        // "/learning": (_) => LearningScreen(),
        // "/backtest": (_) => BacktestScreen(),
        // "/strategy": (_) => StrategyScreen(),
        // "/reports": (_) => ReportsScreen(),
        // "/settings": (_) => SettingsScreen(),
      },

      builder: (context, child) {
        return LayoutBuilder(
          builder: (context, constraints) {
            return MediaQuery(
              data: MediaQuery.of(context).copyWith(
                textScaler: const TextScaler.linear(1),
              ),
              child: child!,
            );
          },
        );
      },
    );
  }
}