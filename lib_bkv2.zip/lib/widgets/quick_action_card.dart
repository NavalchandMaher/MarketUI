import 'package:flutter/material.dart';

class QuickActionsCard extends StatelessWidget {
  final VoidCallback? onRefresh, onBacktest, onRunMarket;
  const QuickActionsCard({
    super.key,
    this.onRefresh,
    this.onBacktest,
    this.onRunMarket,
  });
  @override
  Widget build(BuildContext context) {
    return Card(
      child: Wrap(
        spacing: 12,
        runSpacing: 12,
        children: [
          ElevatedButton.icon(
            onPressed: onRefresh,
            icon: const Icon(Icons.refresh),
            label: const Text('Refresh'),
          ),
          ElevatedButton.icon(
            onPressed: onRunMarket,
            icon: const Icon(Icons.play_arrow),
            label: const Text('Run Market'),
          ),
          ElevatedButton.icon(
            onPressed: onBacktest,
            icon: const Icon(Icons.analytics),
            label: const Text('Backtest'),
          ),
        ],
      ),
    );
  }
}
