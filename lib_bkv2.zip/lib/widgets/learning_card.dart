import 'package:flutter/material.dart';
import '../models/dashboard_model.dart';

class LearningCard extends StatelessWidget {
  final DashboardModel dashboard;
  const LearningCard({super.key, required this.dashboard});
  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: const Icon(Icons.psychology),
        title: const Text('Learning Engine'),
        subtitle: Text('Last Learning: ${dashboard.lastLearning}'),
      ),
    );
  }
}
