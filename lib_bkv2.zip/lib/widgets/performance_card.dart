
import 'package:flutter/material.dart';

import '../models/dashboard_model.dart';
import '../theme/app_theme.dart';

class PerformanceCard extends StatelessWidget {
  final DashboardModel dashboard;
  final bool loading;

  const PerformanceCard({
    super.key,
    required this.dashboard,
    this.loading = false,
  });

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Card(
        child: SizedBox(
          height: 280,
          child: Center(child: CircularProgressIndicator()),
        ),
      );
    }

    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.analytics,color: AppTheme.primary),
                const SizedBox(width:8),
                Text(
                  "Performance",
                  style: Theme.of(context).textTheme.titleLarge,
                ),
              ],
            ),
            const SizedBox(height:20),
            Row(
              children:[
                Expanded(child:_metric("Today's P&L",
                  dashboard.todayPnL.toStringAsFixed(2),
                  dashboard.todayPnL>=0?Colors.green:Colors.red)),
                const SizedBox(width:12),
                Expanded(child:_metric("Win Rate",
                  "${dashboard.winRate.toStringAsFixed(1)}%",
                  Colors.blue)),
              ],
            ),
            const SizedBox(height:12),
            Row(
              children:[
                Expanded(child:_metric("Open Trades",
                  dashboard.openTrades.toString(),
                  Colors.orange)),
                const SizedBox(width:12),
                Expanded(child:_metric("Total Trades",
                  dashboard.totalTrades.toString(),
                  AppTheme.primary)),
              ],
            ),
            const SizedBox(height:20),
            const Text(
              "Trading Score",
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height:8),
            LinearProgressIndicator(
              value: (dashboard.winRate/100).clamp(0.0,1.0),
              minHeight:10,
              borderRadius: BorderRadius.circular(10),
            ),
            const SizedBox(height:10),
            Text(
              dashboard.winRate>=60
                  ? "Excellent strategy performance."
                  : dashboard.winRate>=45
                      ? "Average performance. Continue monitoring."
                      : "Strategy needs improvement.",
            )
          ],
        ),
      ),
    );
  }

  Widget _metric(String title,String value,Color color){
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.darkCard,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children:[
          Text(title,
            style: const TextStyle(color: Colors.grey,fontSize:12),
            textAlign: TextAlign.center),
          const SizedBox(height:8),
          Text(
            value,
            style: TextStyle(
              color: color,
              fontWeight: FontWeight.bold,
              fontSize:20,
            ),
          ),
        ],
      ),
    );
  }
}
