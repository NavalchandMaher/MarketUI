import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import '../models/dashboard_model.dart';

class MarketCard extends StatelessWidget {
  final DashboardModel dashboard;
  final bool loading;

  const MarketCard({
    super.key,
    required this.dashboard,
    this.loading = false,
  });

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return _loadingCard();
    }

    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            //--------------------------------------------------
            // Title
            //--------------------------------------------------

            Row(
              children: [

                const Icon(
                  Icons.show_chart,
                  color: AppTheme.primary,
                ),

                const SizedBox(width: 10),

                Text(
                  "Market Overview",
                  style: Theme.of(context).textTheme.titleLarge,
                ),

                const Spacer(),

                Icon(
                  Icons.circle,
                  color: Colors.green.shade400,
                  size: 12,
                ),

                const SizedBox(width: 6),

                const Text(
                  "LIVE",
                  style: TextStyle(
                    color: Colors.green,
                    fontWeight: FontWeight.bold,
                  ),
                ),

              ],
            ),

            const SizedBox(height: 24),

            //--------------------------------------------------
            // BTC Price
            //--------------------------------------------------

            _priceTile(
              title: "BTCUSDT",
              price: dashboard.btcPrice,
              change: dashboard.btcChange,
            ),

            const SizedBox(height: 14),

            //--------------------------------------------------
            // ETH Price
            //--------------------------------------------------

            _priceTile(
              title: "ETHUSDT",
              price: dashboard.ethPrice,
              change: dashboard.ethChange,
            ),

            const SizedBox(height: 20),

                        //--------------------------------------------------
            // Market Sentiment & Regime
            //--------------------------------------------------

            Row(
              children: [

                Expanded(
                  child: _infoTile(
                    title: "Sentiment",
                    value: dashboard.marketSentiment,
                    color: _sentimentColor(
                      dashboard.marketSentiment,
                    ),
                    icon: Icons.trending_up,
                  ),
                ),

                const SizedBox(width: 12),

                Expanded(
                  child: _infoTile(
                    title: "Regime",
                    value: dashboard.marketRegime,
                    color: _regimeColor(
                      dashboard.marketRegime,
                    ),
                    icon: Icons.auto_graph,
                  ),
                ),

              ],
            ),

            const SizedBox(height: 16),

            //--------------------------------------------------
            // Fear & Greed / Volatility
            //--------------------------------------------------

            Row(
              children: [

                Expanded(
                  child: _infoTile(
                    title: "Fear & Greed",
                    value: dashboard.fearGreed,
                    color: Colors.orange,
                    icon: Icons.psychology,
                  ),
                ),

                const SizedBox(width: 12),

                Expanded(
                  child: _infoTile(
                    title: "Volatility",
                    value: dashboard.volatility,
                    color: Colors.deepPurple,
                    icon: Icons.bolt,
                  ),
                ),

              ],
            ),

            const SizedBox(height: 20),

            //--------------------------------------------------
            // Last Updated
            //--------------------------------------------------

            Row(
              children: [

                const Icon(
                  Icons.schedule,
                  size: 16,
                  color: Colors.grey,
                ),

                const SizedBox(width: 6),

                Text(
                  "Updated : ${dashboard.lastUpdated}",
                  style: Theme.of(context)
                      .textTheme
                      .bodySmall
                      ?.copyWith(
                        color: Colors.grey,
                      ),
                ),

              ],
            ),

          ],
        ),
      ),
    );
  }
    //==========================================================
  // Price Tile
  //==========================================================

  Widget _priceTile({
    required String title,
    required double price,
    required double change,
  }) {
    final positive = change >= 0;

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.darkCard,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 18,
            backgroundColor: AppTheme.primary.withValues(alpha: 0.15),
            child: const Icon(
              Icons.currency_bitcoin,
              color: AppTheme.primary,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  "\$${price.toStringAsFixed(2)}",
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 10,
              vertical: 6,
            ),
            decoration: BoxDecoration(
              color: positive
                  ? Colors.green.withValues(alpha: 0.15)
                  : Colors.red.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              "${positive ? "+" : ""}${change.toStringAsFixed(2)}%",
              style: TextStyle(
                color: positive ? Colors.green : Colors.red,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  //==========================================================
  // Info Tile
  //==========================================================

  Widget _infoTile({
    required String title,
    required String value,
    required Color color,
    required IconData icon,
  }) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.darkCard,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        children: [
          Icon(
            icon,
            color: color,
            size: 28,
          ),
          const SizedBox(height: 10),
          Text(
            title,
            style: const TextStyle(
              color: Colors.grey,
              fontSize: 13,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            value,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: color,
              fontWeight: FontWeight.bold,
              fontSize: 15,
            ),
          ),
        ],
      ),
    );
  }

  //==========================================================
  // Loading Card
  //==========================================================

  Widget _loadingCard() {
    return const Card(
      child: SizedBox(
        height: 320,
        child: Center(
          child: CircularProgressIndicator(),
        ),
      ),
    );
  }

  //==========================================================
  // Helper Colors
  //==========================================================

  Color _sentimentColor(String sentiment) {
    switch (sentiment.toUpperCase()) {
      case "BULLISH":
        return Colors.green;

      case "BEARISH":
        return Colors.red;

      case "NEUTRAL":
        return Colors.orange;

      default:
        return Colors.grey;
    }
  }

  Color _regimeColor(String regime) {
    switch (regime.toUpperCase()) {
      case "TRENDING":
        return Colors.green;

      case "BREAKOUT":
        return Colors.orange;

      case "RANGING":
        return Colors.blue;

      case "VOLATILE":
        return Colors.deepPurple;

      default:
        return Colors.grey;
    }
  }
}