import 'package:flutter/material.dart';
import '../models/dashboard_model.dart';

class StrategyCard extends StatelessWidget {
  final DashboardModel dashboard;
  final bool loading;
  const StrategyCard({
    super.key,
    required this.dashboard,
    this.loading = false,
  });
  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: const Icon(Icons.auto_graph),
        title: Text(dashboard.activeStrategy),
        subtitle: Text('Version ${dashboard.strategyVersion}'),
        trailing: Chip(
          label: Text(dashboard.schedulerRunning ? 'ACTIVE' : 'INACTIVE'),
        ),
      ),
    );
  }
}
