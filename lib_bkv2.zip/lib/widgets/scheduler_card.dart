import 'package:flutter/material.dart';
import '../models/dashboard_model.dart';

class SchedulerCard extends StatelessWidget {
  final DashboardModel dashboard;
  const SchedulerCard({super.key, required this.dashboard});
  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: const Icon(Icons.schedule),
        title: const Text('Scheduler'),
        subtitle: Text(dashboard.schedulerRunning ? 'Running' : 'Stopped'),
      ),
    );
  }
}
