
import 'package:flutter/material.dart';

import '../models/dashboard_model.dart';
import '../theme/app_theme.dart';

class SignalCard extends StatelessWidget {
  final DashboardModel dashboard;
  final bool loading;

  const SignalCard({
    super.key,
    required this.dashboard,
    this.loading = false,
  });

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Card(
        child: SizedBox(
          height: 320,
          child: Center(child: CircularProgressIndicator()),
        ),
      );
    }

    final signal = dashboard.currentSignal.toUpperCase();

    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.psychology, color: AppTheme.primary),
                const SizedBox(width: 8),
                Text("AI Trading Signal",
                    style: Theme.of(context).textTheme.titleLarge),
                const Spacer(),
                Icon(Icons.circle, color: Colors.green, size: 12),
                const SizedBox(width: 4),
                const Text("LIVE"),
              ],
            ),
            const SizedBox(height: 24),
            Center(
              child: Chip(
                backgroundColor: _signalColor(signal).withOpacity(.15),
                side: BorderSide(color: _signalColor(signal)),
                label: Text(
                  signal,
                  style: TextStyle(
                    color: _signalColor(signal),
                    fontWeight: FontWeight.bold,
                    fontSize: 22,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Center(child: Text(_signalDescription(signal))),
            const SizedBox(height: 20),
            Row(
              children: [
                const Text("Confidence"),
                const Spacer(),
                Text("${dashboard.confidence.toStringAsFixed(1)}%"),
              ],
            ),
            const SizedBox(height: 8),
            LinearProgressIndicator(
              value: dashboard.confidence / 100,
              minHeight: 8,
              borderRadius: BorderRadius.circular(12),
            ),
            const SizedBox(height: 20),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.auto_graph),
              title: Text(dashboard.activeStrategy),
              subtitle: Text("Version ${dashboard.strategyVersion}"),
            ),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _signalColor(signal).withOpacity(.08),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(_recommendation(signal)),
            )
          ],
        ),
      ),
    );
  }

  Color _signalColor(String signal) {
    switch (signal) {
      case "BUY":
        return Colors.green;
      case "SELL":
        return Colors.red;
      case "WAIT":
        return Colors.orange;
      default:
        return Colors.grey;
    }
  }

  String _signalDescription(String signal) {
    switch (signal) {
      case "BUY":
        return "Bullish setup detected.";
      case "SELL":
        return "Bearish setup detected.";
      case "WAIT":
        return "No high probability setup.";
      default:
        return "";
    }
  }

  String _recommendation(String signal) {
    switch (signal) {
      case "BUY":
        return "Consider a long trade with proper stop-loss.";
      case "SELL":
        return "Consider a short trade with proper stop-loss.";
      case "WAIT":
        return "Wait for better market confirmation.";
      default:
        return "";
    }
  }
}
