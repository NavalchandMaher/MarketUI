import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

class AppDrawer extends StatelessWidget {
  final String currentRoute;

  const AppDrawer({
    super.key,
    required this.currentRoute,
  });

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: AppTheme.darkSurface,
      child: SafeArea(
        child: Column(
          children: [

            //==================================================
            // Header
            //==================================================

            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(
                vertical: 30,
                horizontal: 20,
              ),
              decoration: const BoxDecoration(
                color: AppTheme.primary,
              ),
              child: Column(
                children: const [

                  CircleAvatar(
                    radius: 38,
                    backgroundColor: Colors.white,
                    child: Icon(
                      Icons.auto_graph,
                      size: 42,
                      color: AppTheme.primary,
                    ),
                  ),

                  SizedBox(height: 15),

                  Text(
                    "Market AI V2",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  SizedBox(height: 6),

                  Text(
                    "AI Trading Platform",
                    style: TextStyle(
                      color: Colors.white70,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 12),

            Expanded(
              child: ListView(
                padding: EdgeInsets.zero,
                children: [

                  _drawerItem(
                    context,
                    icon: Icons.dashboard,
                    title: "Dashboard",
                    route: "/dashboard",
                  ),

                  _drawerItem(
                    context,
                    icon: Icons.analytics,
                    title: "Analysis",
                    route: "/analysis",
                  ),

                  _drawerItem(
                    context,
                    icon: Icons.currency_exchange,
                    title: "Paper Trading",
                    route: "/paper-trades",
                  ),

                  _drawerItem(
                    context,
                    icon: Icons.history,
                    title: "Trade History",
                    route: "/history",
                  ),

                  _drawerItem(
                    context,
                    icon: Icons.bar_chart,
                    title: "Performance",
                    route: "/performance",
                  ),
                                    _drawerItem(
                    context,
                    icon: Icons.psychology,
                    title: "Strategy Manager",
                    route: "/strategy",
                  ),

                  _drawerItem(
                    context,
                    icon: Icons.speed,
                    title: "Backtesting",
                    route: "/backtesting",
                  ),

                  _drawerItem(
                    context,
                    icon: Icons.school,
                    title: "Learning Logs",
                    route: "/learning",
                  ),

                  _drawerItem(
                    context,
                    icon: Icons.description,
                    title: "Reports",
                    route: "/reports",
                  ),

                  _drawerItem(
                    context,
                    icon: Icons.settings,
                    title: "Settings",
                    route: "/settings",
                  ),

                  const Divider(),

                  _drawerItem(
                    context,
                    icon: Icons.info_outline,
                    title: "About",
                    route: "/about",
                  ),
                ],
              ),
            ),

            //--------------------------------------------------
            // Footer
            //--------------------------------------------------

            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              child: Column(
                children: const [

                  Divider(),

                  SizedBox(height: 8),

                  Text(
                    "Market AI V2",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  SizedBox(height: 4),

                  Text(
                    "Version 2.0.0",
                    style: TextStyle(
                      color: Colors.grey,
                      fontSize: 12,
                    ),
                  ),

                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  //==========================================================
  // Drawer Item
  //==========================================================

  Widget _drawerItem(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String route,
  }) {

    final selected = currentRoute == route;

    return ListTile(
      leading: Icon(
        icon,
        color: selected ? AppTheme.primary : Colors.white70,
      ),

      title: Text(
        title,
        style: TextStyle(
          color: selected ? AppTheme.primary : Colors.white,
          fontWeight:
              selected ? FontWeight.bold : FontWeight.normal,
        ),
      ),

      selected: selected,

      selectedTileColor: AppTheme.primary.withValues(alpha: 0.12),

      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),

      onTap: () {
        Navigator.pop(context);

        if (currentRoute != route) {
          Navigator.pushReplacementNamed(
          context,
          route,
        );
        }
      },
    );
  }
}