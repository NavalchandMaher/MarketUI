class DashboardModel {
  //==========================================================
  // Market
  //==========================================================

  final double btcPrice;
  final double btcChange;

  final double ethPrice;
  final double ethChange;

  final String marketSentiment;
  final String marketRegime;

  final String fearGreed;
  final String volatility;

  //==========================================================
  // Signal
  //==========================================================

  final String currentSignal;
  final double confidence;

  //==========================================================
  // Performance
  //==========================================================

  final double todayPnL;

  final int totalTrades;

  final double winRate;

  final int openTrades;

  //==========================================================
  // Strategy
  //==========================================================

  final String activeStrategy;

  final int strategyVersion;

  //==========================================================
  // Scheduler
  //==========================================================

  final bool schedulerRunning;

  //==========================================================
  // Learning
  //==========================================================

  final String lastLearning;

  //==========================================================
  // Misc
  //==========================================================

  final DateTime lastUpdated;

  const DashboardModel({

    required this.btcPrice,
    required this.btcChange,

    required this.ethPrice,
    required this.ethChange,

    required this.marketSentiment,
    required this.marketRegime,

    required this.fearGreed,
    required this.volatility,

    required this.currentSignal,
    required this.confidence,

    required this.todayPnL,

    required this.totalTrades,
    required this.winRate,
    required this.openTrades,

    required this.activeStrategy,
    required this.strategyVersion,

    required this.schedulerRunning,

    required this.lastLearning,

    required this.lastUpdated,
  });

  factory DashboardModel.empty() {
    return DashboardModel(
      btcPrice: 0,
      btcChange: 0,

      ethPrice: 0,
      ethChange: 0,

      marketSentiment: "NEUTRAL",
      marketRegime: "RANGING",

      fearGreed: "Neutral",
      volatility: "Low",

      currentSignal: "WAIT",
      confidence: 0,

      todayPnL: 0,

      totalTrades: 0,
      winRate: 0,
      openTrades: 0,

      activeStrategy: "N/A",
      strategyVersion: 1,

      schedulerRunning: false,

      lastLearning: "",

      lastUpdated: DateTime.now(),
    );
  }

  DashboardModel copyWith({

    double? btcPrice,
    double? btcChange,

    double? ethPrice,
    double? ethChange,

    String? marketSentiment,
    String? marketRegime,

    String? fearGreed,
    String? volatility,

    String? currentSignal,
    double? confidence,

    double? todayPnL,

    int? totalTrades,
    double? winRate,
    int? openTrades,

    String? activeStrategy,
    int? strategyVersion,

    bool? schedulerRunning,

    String? lastLearning,

    DateTime? lastUpdated,

  }) {
    return DashboardModel(

      btcPrice: btcPrice ?? this.btcPrice,
      btcChange: btcChange ?? this.btcChange,

      ethPrice: ethPrice ?? this.ethPrice,
      ethChange: ethChange ?? this.ethChange,

      marketSentiment:
          marketSentiment ?? this.marketSentiment,

      marketRegime:
          marketRegime ?? this.marketRegime,

      fearGreed:
          fearGreed ?? this.fearGreed,

      volatility:
          volatility ?? this.volatility,

      currentSignal:
          currentSignal ?? this.currentSignal,

      confidence:
          confidence ?? this.confidence,

      todayPnL:
          todayPnL ?? this.todayPnL,

      totalTrades:
          totalTrades ?? this.totalTrades,

      winRate:
          winRate ?? this.winRate,

      openTrades:
          openTrades ?? this.openTrades,

      activeStrategy:
          activeStrategy ?? this.activeStrategy,

      strategyVersion:
          strategyVersion ?? this.strategyVersion,

      schedulerRunning:
          schedulerRunning ?? this.schedulerRunning,

      lastLearning:
          lastLearning ?? this.lastLearning,

      lastUpdated:
          lastUpdated ?? this.lastUpdated,
    );
  }

  @override
  String toString() {
    return '''
DashboardModel(
  btcPrice: $btcPrice,
  signal: $currentSignal,
  confidence: $confidence,
  pnl: $todayPnL,
  strategy: $activeStrategy
)
''';
  }
}