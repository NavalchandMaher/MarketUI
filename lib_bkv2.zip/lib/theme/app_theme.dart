import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  AppTheme._();

  // ============================================================
  // Trading Colors
  // ============================================================

  static const Color primary = Color(0xFF2962FF);

  static const Color secondary = Color(0xFF00C853);

  static const Color danger = Color(0xFFD50000);

  static const Color warning = Color(0xFFFFC107);

  static const Color success = Color(0xFF00E676);

  static const Color info = Color(0xFF29B6F6);

  static const Color darkBackground = Color(0xFF121212);

  static const Color darkSurface = Color(0xFF1E1E1E);

  static const Color darkCard = Color(0xFF242424);

  static const Color lightBackground = Color(0xFFF5F7FA);

  static const Color lightCard = Colors.white;

  static const Color bullish = Color(0xFF00C853);

  static const Color bearish = Color(0xFFD50000);

  static const Color neutral = Color(0xFFFFA000);

  static const Color divider = Color(0xFF303030);

  static const Color textPrimary = Colors.white;

  static const Color textSecondary = Colors.white70;

  // ============================================================
  // Font
  // ============================================================

  static TextTheme get textTheme =>
      GoogleFonts.poppinsTextTheme().copyWith(
        headlineLarge: GoogleFonts.poppins(
          fontSize: 30,
          fontWeight: FontWeight.bold,
        ),
        headlineMedium: GoogleFonts.poppins(
          fontSize: 24,
          fontWeight: FontWeight.w700,
        ),
        headlineSmall: GoogleFonts.poppins(
          fontSize: 20,
          fontWeight: FontWeight.w700,
        ),
        titleLarge: GoogleFonts.poppins(
          fontSize: 18,
          fontWeight: FontWeight.w600,
        ),
        titleMedium: GoogleFonts.poppins(
          fontSize: 16,
          fontWeight: FontWeight.w600,
        ),
        titleSmall: GoogleFonts.poppins(
          fontSize: 14,
          fontWeight: FontWeight.w600,
        ),
        bodyLarge: GoogleFonts.poppins(
          fontSize: 16,
          fontWeight: FontWeight.w400,
        ),
        bodyMedium: GoogleFonts.poppins(
          fontSize: 14,
          fontWeight: FontWeight.w400,
        ),
        bodySmall: GoogleFonts.poppins(
          fontSize: 12,
          fontWeight: FontWeight.w400,
        ),
        labelLarge: GoogleFonts.poppins(
          fontSize: 14,
          fontWeight: FontWeight.w600,
        ),
      );

  // ============================================================
  // Light Theme
  // ============================================================

  static ThemeData get lightTheme {
    return ThemeData(
      useMaterial3: true,

      brightness: Brightness.light,

      primaryColor: primary,

      canvasColor: darkSurface,

      splashColor: primary.withValues(alpha: .12),

      highlightColor: Colors.transparent,

      hoverColor: primary.withValues(alpha: .08),

      scaffoldBackgroundColor: lightBackground,

      colorScheme: ColorScheme.fromSeed(
        seedColor: primary,
        brightness: Brightness.light,
        primary: primary,
        secondary: secondary,
        error: danger,
      ),

      textTheme: textTheme,

      fontFamily: GoogleFonts.poppins().fontFamily,

      splashFactory: InkRipple.splashFactory,

      visualDensity: VisualDensity.adaptivePlatformDensity,

      appBarTheme: const AppBarTheme(
        elevation: 0,
        centerTitle: false,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
      ),

      cardTheme: CardThemeData(
        elevation: 2,
        color: lightCard,
        shadowColor: Colors.black12,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
        ),
        margin: EdgeInsets.zero,
      ),

      dividerColor: Colors.grey.shade300,

      iconTheme: const IconThemeData(
        color: primary,
        size: 22,
      ),
      menuTheme: MenuThemeData(
            style: MenuStyle(
                backgroundColor: WidgetStatePropertyAll(darkCard),
            ),
        ),
      popupMenuTheme: PopupMenuThemeData(
            color: darkCard,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
            ),
        ),
        bottomSheetTheme: const BottomSheetThemeData(
            backgroundColor: darkSurface,
            surfaceTintColor: Colors.transparent,
            ),
    );
  }

  // ============================================================
  // Dark Theme
  // (Continues in Part 2.2)
  // ============================================================

  static ThemeData get darkTheme {
    return ThemeData(
      useMaterial3: true,

      brightness: Brightness.dark,

      primaryColor: primary,

      scaffoldBackgroundColor: darkBackground,

      colorScheme: ColorScheme.fromSeed(
        seedColor: primary,
        brightness: Brightness.dark,
        primary: primary,
        secondary: secondary,
        error: danger,
      ),

      textTheme: textTheme.apply(
        bodyColor: Colors.white,
        displayColor: Colors.white,
      ),

      fontFamily: GoogleFonts.poppins().fontFamily,

      splashFactory: InkRipple.splashFactory,

      visualDensity: VisualDensity.adaptivePlatformDensity,

            // ==========================================================
      // AppBar Theme
      // ==========================================================

      appBarTheme: const AppBarTheme(
        elevation: 0,
        centerTitle: false,
        scrolledUnderElevation: 0,
        backgroundColor: darkSurface,
        foregroundColor: Colors.white,
        surfaceTintColor: Colors.transparent,
        titleTextStyle: TextStyle(
          color: Colors.white,
          fontSize: 22,
          fontWeight: FontWeight.bold,
        ),
        iconTheme: IconThemeData(
          color: Colors.white,
          size: 24,
        ),
        actionsIconTheme: IconThemeData(
          color: Colors.white,
          size: 22,
        ),
      ),

      // ==========================================================
      // Card Theme
      // ==========================================================

      cardTheme: CardThemeData(
        color: darkCard,
        elevation: 3,
        shadowColor: Colors.black54,
        surfaceTintColor: Colors.transparent,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
        ),
      ),

      dividerColor: divider,

      iconTheme: const IconThemeData(
        color: Colors.white,
        size: 22,
      ),

      listTileTheme: const ListTileThemeData(
        iconColor: Colors.white70,
        textColor: Colors.white,
        contentPadding: EdgeInsets.symmetric(
          horizontal: 18,
          vertical: 4,
        ),
      ),
          // ==========================================================
      // Elevated Button Theme
      // ==========================================================

      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: primary,
          foregroundColor: Colors.white,
          elevation: 0,
          minimumSize: const Size(double.infinity, 52),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          textStyle: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),

      // ==========================================================
      // Filled Button Theme
      // ==========================================================

      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: secondary,
          foregroundColor: Colors.white,
          minimumSize: const Size(double.infinity, 52),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          textStyle: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),

      // ==========================================================
      // Outlined Button Theme
      // ==========================================================

      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: Colors.white,
          side: BorderSide(
            color: primary.withValues(alpha: 0.7),
            width: 1.5,
          ),
          minimumSize: const Size(double.infinity, 52),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          textStyle: const TextStyle(
            fontWeight: FontWeight.w600,
            fontSize: 15,
          ),
        ),
      ),

      // ==========================================================
      // Text Button Theme
      // ==========================================================

      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: primary,
          textStyle: const TextStyle(
            fontWeight: FontWeight.w600,
            fontSize: 15,
          ),
        ),
      ),
            // ==========================================================
      // Floating Action Button Theme
      // ==========================================================

      floatingActionButtonTheme: const FloatingActionButtonThemeData(
        backgroundColor: primary,
        foregroundColor: Colors.white,
        elevation: 4,
        shape: CircleBorder(),
      ),

      // ==========================================================
      // Bottom Navigation Bar Theme
      // ==========================================================

      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: darkSurface,
        selectedItemColor: primary,
        unselectedItemColor: Colors.white54,
        selectedIconTheme: IconThemeData(size: 26),
        unselectedIconTheme: IconThemeData(size: 22),
        showSelectedLabels: true,
        showUnselectedLabels: true,
        type: BottomNavigationBarType.fixed,
        elevation: 10,
      ),

      // ==========================================================
      // Navigation Bar Theme (Material 3)
      // ==========================================================

      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: darkSurface,
        indicatorColor: primary.withValues(alpha: 0.20),
        iconTheme: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return const IconThemeData(
              color: primary,
              size: 26,
            );
          }

          return const IconThemeData(
            color: Colors.white60,
            size: 22,
          );
        }),
        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return const TextStyle(
              color: primary,
              fontWeight: FontWeight.bold,
            );
          }

          return const TextStyle(
            color: Colors.white60,
          );
        }),
      ),

      // ==========================================================
      // Drawer Theme
      // ==========================================================

      drawerTheme: const DrawerThemeData(
        backgroundColor: darkSurface,
        elevation: 4,
        surfaceTintColor: Colors.transparent,
      ),

      // ==========================================================
      // Navigation Rail Theme
      // ==========================================================

      navigationRailTheme: NavigationRailThemeData(
        backgroundColor: darkSurface,
        selectedIconTheme: const IconThemeData(
          color: primary,
        ),
        unselectedIconTheme: const IconThemeData(
          color: Colors.white54,
        ),
        selectedLabelTextStyle: const TextStyle(
          color: primary,
          fontWeight: FontWeight.bold,
        ),
        unselectedLabelTextStyle: const TextStyle(
          color: Colors.white60,
        ),
        indicatorColor: primary.withValues(alpha: 0.20),
      ),

      // ==========================================================
      // Tab Bar Theme
      // ==========================================================

      tabBarTheme: const TabBarThemeData(
        indicatorColor: primary,
        labelColor: primary,
        unselectedLabelColor: Colors.white60,
        dividerColor: Colors.transparent,
      ),

      // ==========================================================
      // SnackBar Theme
      // ==========================================================

      snackBarTheme: SnackBarThemeData(
        backgroundColor: darkCard,
        contentTextStyle: const TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.w500,
        ),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),

      // ==========================================================
      // Progress Indicator Theme
      // ==========================================================

      progressIndicatorTheme: const ProgressIndicatorThemeData(
        color: primary,
        linearTrackColor: Colors.white12,
        circularTrackColor: Colors.white12,
      ),
            // ==========================================================
      // Input Decoration Theme
      // ==========================================================

      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: darkCard,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 18,
          vertical: 16,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(
            color: Colors.grey.shade800,
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(
            color: primary,
            width: 2,
          ),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(
            color: danger,
            width: 2,
          ),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(
            color: danger,
            width: 2,
          ),
        ),
        hintStyle: const TextStyle(
          color: Colors.white54,
        ),
        labelStyle: const TextStyle(
          color: Colors.white70,
        ),
      ),

      // ==========================================================
      // Text Selection
      // ==========================================================

      textSelectionTheme: const TextSelectionThemeData(
        cursorColor: primary,
        selectionColor: Color(0x552962FF),
        selectionHandleColor: primary,
      ),

      // ==========================================================
      // Checkbox
      // ==========================================================

      checkboxTheme: CheckboxThemeData(
        fillColor: WidgetStateProperty.resolveWith(
          (states) {
            if (states.contains(WidgetState.selected)) {
              return primary;
            }
            return Colors.transparent;
          },
        ),
        checkColor: WidgetStateProperty.all(
          Colors.white,
        ),
      ),

      // ==========================================================
      // Switch
      // ==========================================================

      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith(
          (states) {
            if (states.contains(WidgetState.selected)) {
              return primary;
            }
            return Colors.grey;
          },
        ),
        trackColor: WidgetStateProperty.resolveWith(
          (states) {
            if (states.contains(WidgetState.selected)) {
              return primary.withValues(alpha: 0.35);
            }
            return Colors.white24;
          },
        ),
      ),

      // ==========================================================
      // Radio Button
      // ==========================================================

      radioTheme: RadioThemeData(
        fillColor: WidgetStateProperty.all(primary),
      ),

      // ==========================================================
      // Slider Theme
      // ==========================================================

      sliderTheme: SliderThemeData(
        activeTrackColor: primary,
        inactiveTrackColor: Colors.white24,
        thumbColor: primary,
        overlayColor: primary.withValues(alpha: 0.20),
        valueIndicatorColor: primary,
      ),

      // ==========================================================
      // Chip Theme
      // ==========================================================

      chipTheme: ChipThemeData(
        backgroundColor: darkCard,
        selectedColor: primary,
        disabledColor: Colors.grey.shade800,
        labelStyle: const TextStyle(
          color: Colors.white,
        ),
        secondaryLabelStyle: const TextStyle(
          color: Colors.white,
        ),
        brightness: Brightness.dark,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(25),
        ),
      ),

      // ==========================================================
      // Dialog Theme
      // ==========================================================

      dialogTheme: DialogThemeData(
        backgroundColor: darkSurface,
        elevation: 6,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
        ),
        titleTextStyle: const TextStyle(
          color: Colors.white,
          fontSize: 22,
          fontWeight: FontWeight.bold,
        ),
        contentTextStyle: const TextStyle(
          color: Colors.white70,
          fontSize: 15,
        ),
      ),

      // ==========================================================
      // Divider Theme
      // ==========================================================

      dividerTheme: const DividerThemeData(
        color: divider,
        thickness: .8,
        space: 1,
      ),

      // ==========================================================
      // Tooltip Theme
      // ==========================================================

      tooltipTheme: TooltipThemeData(
        decoration: BoxDecoration(
          color: darkSurface,
          borderRadius: BorderRadius.circular(10),
        ),
        textStyle: const TextStyle(
          color: Colors.white,
          fontSize: 13,
        ),
      ),
        pageTransitionsTheme: const PageTransitionsTheme(
            builders: {
                TargetPlatform.android: FadeUpwardsPageTransitionsBuilder(),
                TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
            },
            ),

      );
    }
    static Color signalColor(String signal) {
  switch (signal.toUpperCase()) {
    case "BUY":
      return bullish;

    case "SELL":
      return bearish;

    default:
      return neutral;
  }
}

static Color pnlColor(double pnl) {
  return pnl >= 0 ? bullish : bearish;
}

static Color regimeColor(String regime) {
  switch (regime.toUpperCase()) {
    case "TRENDING":
      return success;

    case "BREAKOUT":
      return warning;

    case "RANGING":
      return info;

    default:
      return Colors.grey;
  }
}

static Color strategyColor(String strategy) {
  switch (strategy.toUpperCase()) {
    case "EMA_MACD_V1":
      return Colors.blue;

    case "BREAKOUT_VOLUME":
      return Colors.orange;

    case "SUPERTREND_EMA":
      return Colors.purple;

    case "SCALPING_PRO":
      return Colors.teal;

    default:
      return primary;
  }
    }
}
