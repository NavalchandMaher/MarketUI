import 'dart:convert';

/// =============================================================
/// Analysis Model
/// =============================================================

class AnalysisModel {
  //==================================================
  // Market
  //==================================================

  final String symbol;
  final String timeframe;

  final double price;

  //==================================================
  // Signal
  //==================================================

  final String signal;

  final double confidence;

  //==================================================
  // Indicators
  //==================================================

  final double rsi;

  final double ema20;
  final double ema50;
  final double ema200;

  final double macd;
  final double macdSignal;

  final double adx;

  final double volumeRatio;

  //==================================================
  // Support / Resistance
  //==================================================

  final double support;

  final double resistance;

  //==================================================
  // AI
  //==================================================

  final String marketSentiment;

  final String marketRegime;

  final String aiReason;

  //==================================================
  // Risk
  //==================================================

  final double stopLoss;

  final double targetPrice;

  final double riskReward;

  //==================================================
  // Time
  //==================================================

  final DateTime createdAt;

  const AnalysisModel({
    required this.symbol,
    required this.timeframe,
    required this.price,
    required this.signal,
    required this.confidence,
    required this.rsi,
    required this.ema20,
    required this.ema50,
    required this.ema200,
    required this.macd,
    required this.macdSignal,
    required this.adx,
    required this.volumeRatio,
    required this.support,
    required this.resistance,
    required this.marketSentiment,
    required this.marketRegime,
    required this.aiReason,
    required this.stopLoss,
    required this.targetPrice,
    required this.riskReward,
    required this.createdAt,
  });

  factory AnalysisModel.empty() {
    return AnalysisModel(
      symbol: "",
      timeframe: "",
      price: 0,
      signal: "WAIT",
      confidence: 0,
      rsi: 0,
      ema20: 0,
      ema50: 0,
      ema200: 0,
      macd: 0,
      macdSignal: 0,
      adx: 0,
      volumeRatio: 0,
      support: 0,
      resistance: 0,
      marketSentiment: "NEUTRAL",
      marketRegime: "RANGING",
      aiReason: "",
      stopLoss: 0,
      targetPrice: 0,
      riskReward: 0,
      createdAt: DateTime.now(),
    );
  }

  factory AnalysisModel.fromJson(Map<String, dynamic> json) {
    return AnalysisModel(
      symbol: json["symbol"] ?? "",
      timeframe: json["timeframe"] ?? "",
      price: (json["price"] ?? 0).toDouble(),

      signal: json["signal"] ?? "WAIT",
      confidence: (json["confidence"] ?? 0).toDouble(),

      rsi: (json["rsi"] ?? 0).toDouble(),

      ema20: (json["ema20"] ?? 0).toDouble(),
      ema50: (json["ema50"] ?? 0).toDouble(),
      ema200: (json["ema200"] ?? 0).toDouble(),

      macd: (json["macd"] ?? 0).toDouble(),
      macdSignal: (json["macdSignal"] ?? 0).toDouble(),

      adx: (json["adx"] ?? 0).toDouble(),

      volumeRatio: (json["volumeRatio"] ?? 0).toDouble(),

      support: (json["support"] ?? 0).toDouble(),
      resistance: (json["resistance"] ?? 0).toDouble(),

      marketSentiment: json["marketSentiment"] ?? "NEUTRAL",
      marketRegime: json["marketRegime"] ?? "RANGING",

      aiReason: json["aiReason"] ?? "",

      stopLoss: (json["stopLoss"] ?? 0).toDouble(),
      targetPrice: (json["targetPrice"] ?? 0).toDouble(),
      riskReward: (json["riskReward"] ?? 0).toDouble(),

      createdAt: json["createdAt"] != null
          ? DateTime.parse(json["createdAt"])
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "symbol": symbol,
      "timeframe": timeframe,
      "price": price,
      "signal": signal,
      "confidence": confidence,
      "rsi": rsi,
      "ema20": ema20,
      "ema50": ema50,
      "ema200": ema200,
      "macd": macd,
      "macdSignal": macdSignal,
      "adx": adx,
      "volumeRatio": volumeRatio,
      "support": support,
      "resistance": resistance,
      "marketSentiment": marketSentiment,
      "marketRegime": marketRegime,
      "aiReason": aiReason,
      "stopLoss": stopLoss,
      "targetPrice": targetPrice,
      "riskReward": riskReward,
      "createdAt": createdAt.toIso8601String(),
    };
  }

  String toRawJson() => jsonEncode(toJson());

  factory AnalysisModel.fromRawJson(String source) =>
      AnalysisModel.fromJson(jsonDecode(source));

  AnalysisModel copyWith({
    String? symbol,
    String? timeframe,
    double? price,
    String? signal,
    double? confidence,
    double? rsi,
    double? ema20,
    double? ema50,
    double? ema200,
    double? macd,
    double? macdSignal,
    double? adx,
    double? volumeRatio,
    double? support,
    double? resistance,
    String? marketSentiment,
    String? marketRegime,
    String? aiReason,
    double? stopLoss,
    double? targetPrice,
    double? riskReward,
    DateTime? createdAt,
  }) {
    return AnalysisModel(
      symbol: symbol ?? this.symbol,
      timeframe: timeframe ?? this.timeframe,
      price: price ?? this.price,
      signal: signal ?? this.signal,
      confidence: confidence ?? this.confidence,
      rsi: rsi ?? this.rsi,
      ema20: ema20 ?? this.ema20,
      ema50: ema50 ?? this.ema50,
      ema200: ema200 ?? this.ema200,
      macd: macd ?? this.macd,
      macdSignal: macdSignal ?? this.macdSignal,
      adx: adx ?? this.adx,
      volumeRatio: volumeRatio ?? this.volumeRatio,
      support: support ?? this.support,
      resistance: resistance ?? this.resistance,
      marketSentiment: marketSentiment ?? this.marketSentiment,
      marketRegime: marketRegime ?? this.marketRegime,
      aiReason: aiReason ?? this.aiReason,
      stopLoss: stopLoss ?? this.stopLoss,
      targetPrice: targetPrice ?? this.targetPrice,
      riskReward: riskReward ?? this.riskReward,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  bool get isBuy => signal.toUpperCase() == "BUY";

  bool get isSell => signal.toUpperCase() == "SELL";

  bool get isWait => signal.toUpperCase() == "WAIT";

  @override
  String toString() {
    return "AnalysisModel(symbol: $symbol, signal: $signal, confidence: $confidence)";
  }
}

// =============================================================
// Trade Model
// =============================================================

class TradeModel {
  //==================================================
  // Identity
  //==================================================

  final String id;
  final String tradeId;

  //==================================================
  // Market
  //==================================================

  final String symbol;
  final String timeframe;

  //==================================================
  // Strategy
  //==================================================

  final String strategyName;
  final int strategyVersion;

  //==================================================
  // Trade Signal
  //==================================================

  final String signal;
  final double confidence;

  //==================================================
  // Trade Prices
  //==================================================

  final double entryPrice;
  final double exitPrice;

  final double stopLoss;
  final double takeProfit;

  //==================================================
  // Quantity
  //==================================================

  final double quantity;
  final double investment;

  //==================================================
  // Profit
  //==================================================

  final double pnl;
  final double pnlPercent;

  //==================================================
  // Status
  //==================================================

  final String status;

  final bool isWinner;

  //==================================================
  // Market Information
  //==================================================

  final String marketRegime;

  final Map<String, dynamic> indicators;

  //==================================================
  // Dates
  //==================================================

  final DateTime openTime;
  final DateTime? closeTime;

  const TradeModel({
    required this.id,
    required this.tradeId,
    required this.symbol,
    required this.timeframe,
    required this.strategyName,
    required this.strategyVersion,
    required this.signal,
    required this.confidence,
    required this.entryPrice,
    required this.exitPrice,
    required this.stopLoss,
    required this.takeProfit,
    required this.quantity,
    required this.investment,
    required this.pnl,
    required this.pnlPercent,
    required this.status,
    required this.isWinner,
    required this.marketRegime,
    required this.indicators,
    required this.openTime,
    this.closeTime,
  });

  factory TradeModel.empty() {
    return TradeModel(
      id: "",
      tradeId: "",
      symbol: "",
      timeframe: "",
      strategyName: "",
      strategyVersion: 1,
      signal: "WAIT",
      confidence: 0,
      entryPrice: 0,
      exitPrice: 0,
      stopLoss: 0,
      takeProfit: 0,
      quantity: 0,
      investment: 0,
      pnl: 0,
      pnlPercent: 0,
      status: "OPEN",
      isWinner: false,
      marketRegime: "",
      indicators: {},
      openTime: DateTime.now(),
      closeTime: null,
    );
  }

  factory TradeModel.fromJson(Map<String, dynamic> json) {
    return TradeModel(
      id: json["_id"]?.toString() ?? "",

      tradeId: json["trade_id"] ?? "",

      symbol: json["symbol"] ?? "",

      timeframe: json["timeframe"] ?? "",

      strategyName: json["strategy_name"] ?? "",

      strategyVersion: json["strategy_version"] ?? 1,

      signal: json["signal"] ?? "WAIT",

      confidence: (json["confidence"] ?? 0).toDouble(),

      entryPrice: (json["entry_price"] ?? 0).toDouble(),

      exitPrice: (json["exit_price"] ?? 0).toDouble(),

      stopLoss: (json["stop_loss"] ?? 0).toDouble(),

      takeProfit: (json["take_profit"] ?? 0).toDouble(),

      quantity: (json["quantity"] ?? 0).toDouble(),

      investment: (json["investment"] ?? 0).toDouble(),

      pnl: (json["pnl"] ?? 0).toDouble(),

      pnlPercent: (json["pnl_percent"] ?? 0).toDouble(),

      status: json["status"] ?? "OPEN",

      isWinner: json["is_winner"] ?? false,

      marketRegime: json["market_regime"] ?? "",

      indicators:
          Map<String, dynamic>.from(json["indicators"] ?? {}),

      openTime: json["open_time"] != null
          ? DateTime.parse(json["open_time"])
          : DateTime.now(),

      closeTime: json["close_time"] != null
          ? DateTime.parse(json["close_time"])
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "_id": id,
      "trade_id": tradeId,
      "symbol": symbol,
      "timeframe": timeframe,
      "strategy_name": strategyName,
      "strategy_version": strategyVersion,
      "signal": signal,
      "confidence": confidence,
      "entry_price": entryPrice,
      "exit_price": exitPrice,
      "stop_loss": stopLoss,
      "take_profit": takeProfit,
      "quantity": quantity,
      "investment": investment,
      "pnl": pnl,
      "pnl_percent": pnlPercent,
      "status": status,
      "is_winner": isWinner,
      "market_regime": marketRegime,
      "indicators": indicators,
      "open_time": openTime.toIso8601String(),
      "close_time": closeTime?.toIso8601String(),
    };
  }

  String toRawJson() => jsonEncode(toJson());

  factory TradeModel.fromRawJson(String source) =>
      TradeModel.fromJson(jsonDecode(source));

  TradeModel copyWith({
    String? id,
    String? tradeId,
    String? symbol,
    String? timeframe,
    String? strategyName,
    int? strategyVersion,
    String? signal,
    double? confidence,
    double? entryPrice,
    double? exitPrice,
    double? stopLoss,
    double? takeProfit,
    double? quantity,
    double? investment,
    double? pnl,
    double? pnlPercent,
    String? status,
    bool? isWinner,
    String? marketRegime,
    Map<String, dynamic>? indicators,
    DateTime? openTime,
    DateTime? closeTime,
  }) {
    return TradeModel(
      id: id ?? this.id,
      tradeId: tradeId ?? this.tradeId,
      symbol: symbol ?? this.symbol,
      timeframe: timeframe ?? this.timeframe,
      strategyName: strategyName ?? this.strategyName,
      strategyVersion: strategyVersion ?? this.strategyVersion,
      signal: signal ?? this.signal,
      confidence: confidence ?? this.confidence,
      entryPrice: entryPrice ?? this.entryPrice,
      exitPrice: exitPrice ?? this.exitPrice,
      stopLoss: stopLoss ?? this.stopLoss,
      takeProfit: takeProfit ?? this.takeProfit,
      quantity: quantity ?? this.quantity,
      investment: investment ?? this.investment,
      pnl: pnl ?? this.pnl,
      pnlPercent: pnlPercent ?? this.pnlPercent,
      status: status ?? this.status,
      isWinner: isWinner ?? this.isWinner,
      marketRegime: marketRegime ?? this.marketRegime,
      indicators: indicators ?? this.indicators,
      openTime: openTime ?? this.openTime,
      closeTime: closeTime ?? this.closeTime,
    );
  }

  bool get isOpen => status.toUpperCase() == "OPEN";

  bool get isClosed => status.toUpperCase() == "CLOSED";

  bool get isCancelled => status.toUpperCase() == "CANCELLED";

  bool get isBuy => signal.toUpperCase() == "BUY";

  bool get isSell => signal.toUpperCase() == "SELL";

  bool get isProfit => pnl >= 0;

  @override
  String toString() {
    return '''
TradeModel(
  tradeId: $tradeId,
  symbol: $symbol,
  signal: $signal,
  entry: $entryPrice,
  exit: $exitPrice,
  pnl: $pnl
)
''';
  }
}

// =============================================================
// Performance Model
// =============================================================

class PerformanceModel {
  //==================================================
  // Identity
  //==================================================

  final String id;

  final String symbol;

  final String timeframe;

  final String strategyName;

  final int strategyVersion;

  //==================================================
  // Trades
  //==================================================

  final int totalTrades;

  final int wins;

  final int losses;

  final int breakeven;

  //==================================================
  // Win Statistics
  //==================================================

  final double winRate;

  final double lossRate;

  //==================================================
  // Profit
  //==================================================

  final double grossProfit;

  final double grossLoss;

  final double netProfit;

  final double averageProfit;

  final double averageLoss;

  final double expectancy;

  //==================================================
  // Risk Metrics
  //==================================================

  final double profitFactor;

  final double sharpeRatio;

  final double maxDrawdown;

  final double recoveryFactor;

  //==================================================
  // AI Statistics
  //==================================================

  final double averageConfidence;

  final double bestConfidence;

  final double worstConfidence;

  //==================================================
  // Trade Duration
  //==================================================

  final double averageHoldingMinutes;

  final double longestTradeMinutes;

  final double shortestTradeMinutes;

  //==================================================
  // Time
  //==================================================

  final DateTime createdAt;

  const PerformanceModel({
    required this.id,
    required this.symbol,
    required this.timeframe,
    required this.strategyName,
    required this.strategyVersion,
    required this.totalTrades,
    required this.wins,
    required this.losses,
    required this.breakeven,
    required this.winRate,
    required this.lossRate,
    required this.grossProfit,
    required this.grossLoss,
    required this.netProfit,
    required this.averageProfit,
    required this.averageLoss,
    required this.expectancy,
    required this.profitFactor,
    required this.sharpeRatio,
    required this.maxDrawdown,
    required this.recoveryFactor,
    required this.averageConfidence,
    required this.bestConfidence,
    required this.worstConfidence,
    required this.averageHoldingMinutes,
    required this.longestTradeMinutes,
    required this.shortestTradeMinutes,
    required this.createdAt,
  });

  factory PerformanceModel.empty() {
    return PerformanceModel(
      id: "",
      symbol: "",
      timeframe: "",
      strategyName: "",
      strategyVersion: 1,
      totalTrades: 0,
      wins: 0,
      losses: 0,
      breakeven: 0,
      winRate: 0,
      lossRate: 0,
      grossProfit: 0,
      grossLoss: 0,
      netProfit: 0,
      averageProfit: 0,
      averageLoss: 0,
      expectancy: 0,
      profitFactor: 0,
      sharpeRatio: 0,
      maxDrawdown: 0,
      recoveryFactor: 0,
      averageConfidence: 0,
      bestConfidence: 0,
      worstConfidence: 0,
      averageHoldingMinutes: 0,
      longestTradeMinutes: 0,
      shortestTradeMinutes: 0,
      createdAt: DateTime.now(),
    );
  }

  factory PerformanceModel.fromJson(Map<String, dynamic> json) {
    return PerformanceModel(
      id: json["_id"]?.toString() ?? "",
      symbol: json["symbol"] ?? "",
      timeframe: json["timeframe"] ?? "",
      strategyName: json["strategy_name"] ?? "",
      strategyVersion: json["strategy_version"] ?? 1,
      totalTrades: json["total_trades"] ?? 0,
      wins: json["wins"] ?? 0,
      losses: json["losses"] ?? 0,
      breakeven: json["breakeven"] ?? 0,
      winRate: (json["win_rate"] ?? 0).toDouble(),
      lossRate: (json["loss_rate"] ?? 0).toDouble(),
      grossProfit: (json["gross_profit"] ?? 0).toDouble(),
      grossLoss: (json["gross_loss"] ?? 0).toDouble(),
      netProfit: (json["net_profit"] ?? 0).toDouble(),
      averageProfit: (json["average_profit"] ?? 0).toDouble(),
      averageLoss: (json["average_loss"] ?? 0).toDouble(),
      expectancy: (json["expectancy"] ?? 0).toDouble(),
      profitFactor: (json["profit_factor"] ?? 0).toDouble(),
      sharpeRatio: (json["sharpe_ratio"] ?? 0).toDouble(),
      maxDrawdown: (json["drawdown"] ?? 0).toDouble(),
      recoveryFactor: (json["recovery_factor"] ?? 0).toDouble(),
      averageConfidence:
          (json["average_confidence"] ?? 0).toDouble(),
      bestConfidence:
          (json["best_confidence"] ?? 0).toDouble(),
      worstConfidence:
          (json["worst_confidence"] ?? 0).toDouble(),
      averageHoldingMinutes:
          (json["average_holding_minutes"] ?? 0).toDouble(),
      longestTradeMinutes:
          (json["longest_trade_minutes"] ?? 0).toDouble(),
      shortestTradeMinutes:
          (json["shortest_trade_minutes"] ?? 0).toDouble(),
      createdAt: json["created_at"] != null
          ? DateTime.parse(json["created_at"])
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "_id": id,
      "symbol": symbol,
      "timeframe": timeframe,
      "strategy_name": strategyName,
      "strategy_version": strategyVersion,
      "total_trades": totalTrades,
      "wins": wins,
      "losses": losses,
      "breakeven": breakeven,
      "win_rate": winRate,
      "loss_rate": lossRate,
      "gross_profit": grossProfit,
      "gross_loss": grossLoss,
      "net_profit": netProfit,
      "average_profit": averageProfit,
      "average_loss": averageLoss,
      "expectancy": expectancy,
      "profit_factor": profitFactor,
      "sharpe_ratio": sharpeRatio,
      "drawdown": maxDrawdown,
      "recovery_factor": recoveryFactor,
      "average_confidence": averageConfidence,
      "best_confidence": bestConfidence,
      "worst_confidence": worstConfidence,
      "average_holding_minutes": averageHoldingMinutes,
      "longest_trade_minutes": longestTradeMinutes,
      "shortest_trade_minutes": shortestTradeMinutes,
      "created_at": createdAt.toIso8601String(),
    };
  }

  String toRawJson() => jsonEncode(toJson());

  factory PerformanceModel.fromRawJson(String source) =>
      PerformanceModel.fromJson(jsonDecode(source));

  PerformanceModel copyWith({
    String? id,
    String? symbol,
    String? timeframe,
    String? strategyName,
    int? strategyVersion,
    int? totalTrades,
    int? wins,
    int? losses,
    int? breakeven,
    double? winRate,
    double? lossRate,
    double? grossProfit,
    double? grossLoss,
    double? netProfit,
    double? averageProfit,
    double? averageLoss,
    double? expectancy,
    double? profitFactor,
    double? sharpeRatio,
    double? maxDrawdown,
    double? recoveryFactor,
    double? averageConfidence,
    double? bestConfidence,
    double? worstConfidence,
    double? averageHoldingMinutes,
    double? longestTradeMinutes,
    double? shortestTradeMinutes,
    DateTime? createdAt,
  }) {
    return PerformanceModel(
      id: id ?? this.id,
      symbol: symbol ?? this.symbol,
      timeframe: timeframe ?? this.timeframe,
      strategyName: strategyName ?? this.strategyName,
      strategyVersion: strategyVersion ?? this.strategyVersion,
      totalTrades: totalTrades ?? this.totalTrades,
      wins: wins ?? this.wins,
      losses: losses ?? this.losses,
      breakeven: breakeven ?? this.breakeven,
      winRate: winRate ?? this.winRate,
      lossRate: lossRate ?? this.lossRate,
      grossProfit: grossProfit ?? this.grossProfit,
      grossLoss: grossLoss ?? this.grossLoss,
      netProfit: netProfit ?? this.netProfit,
      averageProfit: averageProfit ?? this.averageProfit,
      averageLoss: averageLoss ?? this.averageLoss,
      expectancy: expectancy ?? this.expectancy,
      profitFactor: profitFactor ?? this.profitFactor,
      sharpeRatio: sharpeRatio ?? this.sharpeRatio,
      maxDrawdown: maxDrawdown ?? this.maxDrawdown,
      recoveryFactor: recoveryFactor ?? this.recoveryFactor,
      averageConfidence:
          averageConfidence ?? this.averageConfidence,
      bestConfidence: bestConfidence ?? this.bestConfidence,
      worstConfidence: worstConfidence ?? this.worstConfidence,
      averageHoldingMinutes:
          averageHoldingMinutes ?? this.averageHoldingMinutes,
      longestTradeMinutes:
          longestTradeMinutes ?? this.longestTradeMinutes,
      shortestTradeMinutes:
          shortestTradeMinutes ?? this.shortestTradeMinutes,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  bool get isProfitable => netProfit > 0;

  bool get isExcellent => profitFactor >= 2.0;

  bool get isGood => profitFactor >= 1.5;

  bool get isAverage => profitFactor >= 1.2;

  @override
  String toString() {
    return '''
PerformanceModel(
  strategy: $strategyName
  trades: $totalTrades
  winRate: $winRate
  netProfit: $netProfit
  profitFactor: $profitFactor
)
''';
  }
}

// =============================================================
// Backtest Model
// =============================================================

class BacktestModel {
  //==================================================
  // Identity
  //==================================================

  final String id;

  final String strategyName;

  final int strategyVersion;

  //==================================================
  // Market
  //==================================================

  final String symbol;

  final String timeframe;

  final int days;

  //==================================================
  // Trade Statistics
  //==================================================

  final int totalTrades;

  final int wins;

  final int losses;

  final int breakeven;

  //==================================================
  // Performance
  //==================================================

  final double winRate;

  final double lossRate;

  final double grossProfit;

  final double grossLoss;

  final double netProfit;

  final double averageProfit;

  final double averageLoss;

  final double expectancy;

  //==================================================
  // Risk Metrics
  //==================================================

  final double profitFactor;

  final double sharpeRatio;

  final double sortinoRatio;

  final double maxDrawdown;

  final double recoveryFactor;

  final double calmarRatio;

  //==================================================
  // AI Metrics
  //==================================================

  final double averageConfidence;

  final double bestConfidence;

  final double worstConfidence;

  //==================================================
  // Trade Duration
  //==================================================

  final double averageHoldingMinutes;

  final double longestTradeMinutes;

  final double shortestTradeMinutes;

  //==================================================
  // Result
  //==================================================

  final String grade;

  final bool passed;

  final String remarks;

  //==================================================
  // Time
  //==================================================

  final DateTime createdAt;

  const BacktestModel({
    required this.id,
    required this.strategyName,
    required this.strategyVersion,
    required this.symbol,
    required this.timeframe,
    required this.days,
    required this.totalTrades,
    required this.wins,
    required this.losses,
    required this.breakeven,
    required this.winRate,
    required this.lossRate,
    required this.grossProfit,
    required this.grossLoss,
    required this.netProfit,
    required this.averageProfit,
    required this.averageLoss,
    required this.expectancy,
    required this.profitFactor,
    required this.sharpeRatio,
    required this.sortinoRatio,
    required this.maxDrawdown,
    required this.recoveryFactor,
    required this.calmarRatio,
    required this.averageConfidence,
    required this.bestConfidence,
    required this.worstConfidence,
    required this.averageHoldingMinutes,
    required this.longestTradeMinutes,
    required this.shortestTradeMinutes,
    required this.grade,
    required this.passed,
    required this.remarks,
    required this.createdAt,
  });

  factory BacktestModel.empty() {
    return BacktestModel(
      id: "",
      strategyName: "",
      strategyVersion: 1,
      symbol: "",
      timeframe: "",
      days: 30,
      totalTrades: 0,
      wins: 0,
      losses: 0,
      breakeven: 0,
      winRate: 0,
      lossRate: 0,
      grossProfit: 0,
      grossLoss: 0,
      netProfit: 0,
      averageProfit: 0,
      averageLoss: 0,
      expectancy: 0,
      profitFactor: 0,
      sharpeRatio: 0,
      sortinoRatio: 0,
      maxDrawdown: 0,
      recoveryFactor: 0,
      calmarRatio: 0,
      averageConfidence: 0,
      bestConfidence: 0,
      worstConfidence: 0,
      averageHoldingMinutes: 0,
      longestTradeMinutes: 0,
      shortestTradeMinutes: 0,
      grade: "N/A",
      passed: false,
      remarks: "",
      createdAt: DateTime.now(),
    );
  }

  factory BacktestModel.fromJson(Map<String, dynamic> json) {
    return BacktestModel(
      id: json["_id"]?.toString() ?? "",
      strategyName: json["strategy_name"] ?? "",
      strategyVersion: json["strategy_version"] ?? 1,
      symbol: json["symbol"] ?? "",
      timeframe: json["timeframe"] ?? "",
      days: json["days"] ?? 30,
      totalTrades: json["total_trades"] ?? 0,
      wins: json["wins"] ?? 0,
      losses: json["losses"] ?? 0,
      breakeven: json["breakeven"] ?? 0,
      winRate: (json["win_rate"] ?? 0).toDouble(),
      lossRate: (json["loss_rate"] ?? 0).toDouble(),
      grossProfit: (json["gross_profit"] ?? 0).toDouble(),
      grossLoss: (json["gross_loss"] ?? 0).toDouble(),
      netProfit: (json["net_profit"] ?? 0).toDouble(),
      averageProfit: (json["average_profit"] ?? 0).toDouble(),
      averageLoss: (json["average_loss"] ?? 0).toDouble(),
      expectancy: (json["expectancy"] ?? 0).toDouble(),
      profitFactor: (json["profit_factor"] ?? 0).toDouble(),
      sharpeRatio: (json["sharpe_ratio"] ?? 0).toDouble(),
      sortinoRatio: (json["sortino_ratio"] ?? 0).toDouble(),
      maxDrawdown: (json["drawdown"] ?? 0).toDouble(),
      recoveryFactor: (json["recovery_factor"] ?? 0).toDouble(),
      calmarRatio: (json["calmar_ratio"] ?? 0).toDouble(),
      averageConfidence:
          (json["average_confidence"] ?? 0).toDouble(),
      bestConfidence:
          (json["best_confidence"] ?? 0).toDouble(),
      worstConfidence:
          (json["worst_confidence"] ?? 0).toDouble(),
      averageHoldingMinutes:
          (json["average_holding_minutes"] ?? 0).toDouble(),
      longestTradeMinutes:
          (json["longest_trade_minutes"] ?? 0).toDouble(),
      shortestTradeMinutes:
          (json["shortest_trade_minutes"] ?? 0).toDouble(),
      grade: json["grade"] ?? "N/A",
      passed: json["passed"] ?? false,
      remarks: json["remarks"] ?? "",
      createdAt: json["created_at"] != null
          ? DateTime.parse(json["created_at"])
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() => {
        "_id": id,
        "strategy_name": strategyName,
        "strategy_version": strategyVersion,
        "symbol": symbol,
        "timeframe": timeframe,
        "days": days,
        "total_trades": totalTrades,
        "wins": wins,
        "losses": losses,
        "breakeven": breakeven,
        "win_rate": winRate,
        "loss_rate": lossRate,
        "gross_profit": grossProfit,
        "gross_loss": grossLoss,
        "net_profit": netProfit,
        "average_profit": averageProfit,
        "average_loss": averageLoss,
        "expectancy": expectancy,
        "profit_factor": profitFactor,
        "sharpe_ratio": sharpeRatio,
        "sortino_ratio": sortinoRatio,
        "drawdown": maxDrawdown,
        "recovery_factor": recoveryFactor,
        "calmar_ratio": calmarRatio,
        "average_confidence": averageConfidence,
        "best_confidence": bestConfidence,
        "worst_confidence": worstConfidence,
        "average_holding_minutes": averageHoldingMinutes,
        "longest_trade_minutes": longestTradeMinutes,
        "shortest_trade_minutes": shortestTradeMinutes,
        "grade": grade,
        "passed": passed,
        "remarks": remarks,
        "created_at": createdAt.toIso8601String(),
      };

  String toRawJson() => jsonEncode(toJson());

  factory BacktestModel.fromRawJson(String source) =>
      BacktestModel.fromJson(jsonDecode(source));

  BacktestModel copyWith({
    String? id,
    String? strategyName,
    int? strategyVersion,
    String? symbol,
    String? timeframe,
    int? days,
    int? totalTrades,
    int? wins,
    int? losses,
    int? breakeven,
    double? winRate,
    double? lossRate,
    double? grossProfit,
    double? grossLoss,
    double? netProfit,
    double? averageProfit,
    double? averageLoss,
    double? expectancy,
    double? profitFactor,
    double? sharpeRatio,
    double? sortinoRatio,
    double? maxDrawdown,
    double? recoveryFactor,
    double? calmarRatio,
    double? averageConfidence,
    double? bestConfidence,
    double? worstConfidence,
    double? averageHoldingMinutes,
    double? longestTradeMinutes,
    double? shortestTradeMinutes,
    String? grade,
    bool? passed,
    String? remarks,
    DateTime? createdAt,
  }) {
    return BacktestModel(
      id: id ?? this.id,
      strategyName: strategyName ?? this.strategyName,
      strategyVersion: strategyVersion ?? this.strategyVersion,
      symbol: symbol ?? this.symbol,
      timeframe: timeframe ?? this.timeframe,
      days: days ?? this.days,
      totalTrades: totalTrades ?? this.totalTrades,
      wins: wins ?? this.wins,
      losses: losses ?? this.losses,
      breakeven: breakeven ?? this.breakeven,
      winRate: winRate ?? this.winRate,
      lossRate: lossRate ?? this.lossRate,
      grossProfit: grossProfit ?? this.grossProfit,
      grossLoss: grossLoss ?? this.grossLoss,
      netProfit: netProfit ?? this.netProfit,
      averageProfit: averageProfit ?? this.averageProfit,
      averageLoss: averageLoss ?? this.averageLoss,
      expectancy: expectancy ?? this.expectancy,
      profitFactor: profitFactor ?? this.profitFactor,
      sharpeRatio: sharpeRatio ?? this.sharpeRatio,
      sortinoRatio: sortinoRatio ?? this.sortinoRatio,
      maxDrawdown: maxDrawdown ?? this.maxDrawdown,
      recoveryFactor: recoveryFactor ?? this.recoveryFactor,
      calmarRatio: calmarRatio ?? this.calmarRatio,
      averageConfidence:
          averageConfidence ?? this.averageConfidence,
      bestConfidence: bestConfidence ?? this.bestConfidence,
      worstConfidence: worstConfidence ?? this.worstConfidence,
      averageHoldingMinutes:
          averageHoldingMinutes ?? this.averageHoldingMinutes,
      longestTradeMinutes:
          longestTradeMinutes ?? this.longestTradeMinutes,
      shortestTradeMinutes:
          shortestTradeMinutes ?? this.shortestTradeMinutes,
      grade: grade ?? this.grade,
      passed: passed ?? this.passed,
      remarks: remarks ?? this.remarks,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  bool get isProfitable => netProfit > 0;

  bool get isExcellent => profitFactor >= 2.0;

  bool get isPassed => passed;

  @override
  String toString() {
    return '''
BacktestModel(
  strategy: $strategyName
  trades: $totalTrades
  winRate: $winRate
  netProfit: $netProfit
  grade: $grade
)
''';
  }
}
