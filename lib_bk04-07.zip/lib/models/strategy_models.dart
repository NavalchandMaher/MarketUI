import 'dart:convert';

/// =============================================================
/// Strategy Model
/// =============================================================

class StrategyModel {
  //==================================================
  // Identity
  //==================================================

  final String id;

  final String strategyName;

  final int version;

  final bool enabled;

  //==================================================
  // Strategy Type
  //==================================================

  final String strategyType;

  final String description;

  //==================================================
  // EMA Settings
  //==================================================

  final int emaFast;

  final int emaSlow;

  final int emaTrend;

  //==================================================
  // RSI
  //==================================================

  final int rsiPeriod;

  final double rsiBuy;

  final double rsiSell;

  //==================================================
  // MACD
  //==================================================

  final int macdFast;

  final int macdSlow;

  final int macdSignal;

  //==================================================
  // ADX
  //==================================================

  final int adxPeriod;

  final double adxMinimum;

  //==================================================
  // Volume
  //==================================================

  final double volumeMultiplier;

  //==================================================
  // Risk Management
  //==================================================

  final double riskPercentage;

  final double stopLossPercentage;

  final double takeProfitPercentage;

  final double trailingStopPercentage;

  final bool useTrailingStop;

  //==================================================
  // AI Configuration
  //==================================================

  final bool aiEnabled;

  final int buyThreshold;

  final int sellThreshold;

  //==================================================
  // Performance
  //==================================================

  final int totalTrades;

  final int wins;

  final int losses;

  final double winRate;

  final double profitFactor;

  //==================================================
  // Status
  //==================================================

  final bool paperTrading;

  final bool liveTrading;

  //==================================================
  // Metadata
  //==================================================

  final DateTime createdAt;

  final DateTime updatedAt;

  const StrategyModel({
    required this.id,
    required this.strategyName,
    required this.version,
    required this.enabled,
    required this.strategyType,
    required this.description,
    required this.emaFast,
    required this.emaSlow,
    required this.emaTrend,
    required this.rsiPeriod,
    required this.rsiBuy,
    required this.rsiSell,
    required this.macdFast,
    required this.macdSlow,
    required this.macdSignal,
    required this.adxPeriod,
    required this.adxMinimum,
    required this.volumeMultiplier,
    required this.riskPercentage,
    required this.stopLossPercentage,
    required this.takeProfitPercentage,
    required this.trailingStopPercentage,
    required this.useTrailingStop,
    required this.aiEnabled,
    required this.buyThreshold,
    required this.sellThreshold,
    required this.totalTrades,
    required this.wins,
    required this.losses,
    required this.winRate,
    required this.profitFactor,
    required this.paperTrading,
    required this.liveTrading,
    required this.createdAt,
    required this.updatedAt,
  });

  factory StrategyModel.empty() {
    return StrategyModel(
      id: "",
      strategyName: "",
      version: 1,
      enabled: true,
      strategyType: "EMA",
      description: "",
      emaFast: 20,
      emaSlow: 50,
      emaTrend: 200,
      rsiPeriod: 14,
      rsiBuy: 35,
      rsiSell: 65,
      macdFast: 12,
      macdSlow: 26,
      macdSignal: 9,
      adxPeriod: 14,
      adxMinimum: 25,
      volumeMultiplier: 1.5,
      riskPercentage: 2,
      stopLossPercentage: 1,
      takeProfitPercentage: 2,
      trailingStopPercentage: 1,
      useTrailingStop: true,
      aiEnabled: true,
      buyThreshold: 3,
      sellThreshold: -3,
      totalTrades: 0,
      wins: 0,
      losses: 0,
      winRate: 0,
      profitFactor: 0,
      paperTrading: true,
      liveTrading: false,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );
  }

  factory StrategyModel.fromJson(Map<String, dynamic> json) {
    return StrategyModel(
      id: json["_id"]?.toString() ?? "",
      strategyName: json["strategy_name"] ?? "",
      version: json["version"] ?? 1,
      enabled: json["enabled"] ?? true,
      strategyType: json["strategy_type"] ?? "EMA",
      description: json["description"] ?? "",
      emaFast: json["ema_fast"] ?? 20,
      emaSlow: json["ema_slow"] ?? 50,
      emaTrend: json["ema_trend"] ?? 200,
      rsiPeriod: json["rsi_period"] ?? 14,
      rsiBuy: (json["rsi_buy"] ?? 35).toDouble(),
      rsiSell: (json["rsi_sell"] ?? 65).toDouble(),
      macdFast: json["macd_fast"] ?? 12,
      macdSlow: json["macd_slow"] ?? 26,
      macdSignal: json["macd_signal"] ?? 9,
      adxPeriod: json["adx_period"] ?? 14,
      adxMinimum: (json["adx_minimum"] ?? 25).toDouble(),
      volumeMultiplier:
          (json["volume_multiplier"] ?? 1.5).toDouble(),
      riskPercentage:
          (json["risk_percentage"] ?? 2).toDouble(),
      stopLossPercentage:
          (json["stop_loss_percentage"] ?? 1).toDouble(),
      takeProfitPercentage:
          (json["take_profit_percentage"] ?? 2).toDouble(),
      trailingStopPercentage:
          (json["trailing_stop_percentage"] ?? 1).toDouble(),
      useTrailingStop:
          json["use_trailing_stop"] ?? true,
      aiEnabled: json["ai_enabled"] ?? true,
      buyThreshold: json["buy_threshold"] ?? 3,
      sellThreshold: json["sell_threshold"] ?? -3,
      totalTrades: json["total_trades"] ?? 0,
      wins: json["wins"] ?? 0,
      losses: json["losses"] ?? 0,
      winRate: (json["win_rate"] ?? 0).toDouble(),
      profitFactor:
          (json["profit_factor"] ?? 0).toDouble(),
      paperTrading: json["paper_trading"] ?? true,
      liveTrading: json["live_trading"] ?? false,
      createdAt: json["created_at"] != null
          ? DateTime.parse(json["created_at"])
          : DateTime.now(),
      updatedAt: json["updated_at"] != null
          ? DateTime.parse(json["updated_at"])
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() => {
        "_id": id,
        "strategy_name": strategyName,
        "version": version,
        "enabled": enabled,
        "strategy_type": strategyType,
        "description": description,
        "ema_fast": emaFast,
        "ema_slow": emaSlow,
        "ema_trend": emaTrend,
        "rsi_period": rsiPeriod,
        "rsi_buy": rsiBuy,
        "rsi_sell": rsiSell,
        "macd_fast": macdFast,
        "macd_slow": macdSlow,
        "macd_signal": macdSignal,
        "adx_period": adxPeriod,
        "adx_minimum": adxMinimum,
        "volume_multiplier": volumeMultiplier,
        "risk_percentage": riskPercentage,
        "stop_loss_percentage": stopLossPercentage,
        "take_profit_percentage": takeProfitPercentage,
        "trailing_stop_percentage":
            trailingStopPercentage,
        "use_trailing_stop": useTrailingStop,
        "ai_enabled": aiEnabled,
        "buy_threshold": buyThreshold,
        "sell_threshold": sellThreshold,
        "total_trades": totalTrades,
        "wins": wins,
        "losses": losses,
        "win_rate": winRate,
        "profit_factor": profitFactor,
        "paper_trading": paperTrading,
        "live_trading": liveTrading,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
      };

  String toRawJson() => jsonEncode(toJson());

  factory StrategyModel.fromRawJson(String source) =>
      StrategyModel.fromJson(jsonDecode(source));

  bool get isProfitable => profitFactor >= 1.2;

  bool get isActive => enabled;

  bool get canTrade =>
      enabled && (paperTrading || liveTrading);

  @override
  String toString() {
    return '''
StrategyModel(
  strategy: $strategyName
  version: $version
  enabled: $enabled
  winRate: $winRate
  profitFactor: $profitFactor
)
''';
  }
}

// =============================================================
// Learning Log Model
// =============================================================

class LearningLogModel {
  //==================================================
  // Identity
  //==================================================

  final String id;
  final String learningId;

  //==================================================
  // Strategy
  //==================================================

  final String strategyName;
  final int strategyVersion;

  //==================================================
  // Market
  //==================================================

  final String symbol;
  final String timeframe;
  final String marketRegime;

  //==================================================
  // Learning
  //==================================================

  final String learningType;

  // NIGHTLY
  // ONLINE
  // BACKTEST
  // MANUAL

  final String action;
  final String description;

  //==================================================
  // Previous Performance
  //==================================================

  final double previousWinRate;
  final double previousProfitFactor;
  final double previousNetProfit;

  //==================================================
  // New Performance
  //==================================================

  final double newWinRate;
  final double newProfitFactor;
  final double newNetProfit;

  //==================================================
  // AI
  //==================================================

  final double confidence;

  final bool improvement;

  //==================================================
  // Parameter Changes
  //==================================================

  final Map<String, dynamic> oldParameters;

  final Map<String, dynamic> newParameters;

  //==================================================
  // Statistics
  //==================================================

  final int tradesAnalyzed;

  final int tradesImproved;

  final int tradesRejected;

  //==================================================
  // Execution
  //==================================================

  final bool success;

  final String message;

  final String error;

  //==================================================
  // Time
  //==================================================

  final DateTime createdAt;

  const LearningLogModel({
    required this.id,
    required this.learningId,
    required this.strategyName,
    required this.strategyVersion,
    required this.symbol,
    required this.timeframe,
    required this.marketRegime,
    required this.learningType,
    required this.action,
    required this.description,
    required this.previousWinRate,
    required this.previousProfitFactor,
    required this.previousNetProfit,
    required this.newWinRate,
    required this.newProfitFactor,
    required this.newNetProfit,
    required this.confidence,
    required this.improvement,
    required this.oldParameters,
    required this.newParameters,
    required this.tradesAnalyzed,
    required this.tradesImproved,
    required this.tradesRejected,
    required this.success,
    required this.message,
    required this.error,
    required this.createdAt,
  });

  factory LearningLogModel.empty() {
    return LearningLogModel(
      id: "",
      learningId: "",
      strategyName: "",
      strategyVersion: 1,
      symbol: "",
      timeframe: "",
      marketRegime: "",
      learningType: "NIGHTLY",
      action: "",
      description: "",
      previousWinRate: 0,
      previousProfitFactor: 0,
      previousNetProfit: 0,
      newWinRate: 0,
      newProfitFactor: 0,
      newNetProfit: 0,
      confidence: 0,
      improvement: false,
      oldParameters: {},
      newParameters: {},
      tradesAnalyzed: 0,
      tradesImproved: 0,
      tradesRejected: 0,
      success: true,
      message: "",
      error: "",
      createdAt: DateTime.now(),
    );
  }

  factory LearningLogModel.fromJson(Map<String, dynamic> json) {
    return LearningLogModel(
      id: json["_id"]?.toString() ?? "",
      learningId: json["learning_id"] ?? "",
      strategyName: json["strategy_name"] ?? "",
      strategyVersion: json["strategy_version"] ?? 1,
      symbol: json["symbol"] ?? "",
      timeframe: json["timeframe"] ?? "",
      marketRegime: json["market_regime"] ?? "",
      learningType: json["learning_type"] ?? "NIGHTLY",
      action: json["action"] ?? "",
      description: json["description"] ?? "",
      previousWinRate:
          (json["previous_win_rate"] ?? 0).toDouble(),
      previousProfitFactor:
          (json["previous_profit_factor"] ?? 0).toDouble(),
      previousNetProfit:
          (json["previous_net_profit"] ?? 0).toDouble(),
      newWinRate:
          (json["new_win_rate"] ?? 0).toDouble(),
      newProfitFactor:
          (json["new_profit_factor"] ?? 0).toDouble(),
      newNetProfit:
          (json["new_net_profit"] ?? 0).toDouble(),
      confidence:
          (json["confidence"] ?? 0).toDouble(),
      improvement: json["improvement"] ?? false,
      oldParameters:
          Map<String, dynamic>.from(json["old_parameters"] ?? {}),
      newParameters:
          Map<String, dynamic>.from(json["new_parameters"] ?? {}),
      tradesAnalyzed: json["trades_analyzed"] ?? 0,
      tradesImproved: json["trades_improved"] ?? 0,
      tradesRejected: json["trades_rejected"] ?? 0,
      success: json["success"] ?? true,
      message: json["message"] ?? "",
      error: json["error"] ?? "",
      createdAt: json["created_at"] != null
          ? DateTime.parse(json["created_at"])
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() => {
        "_id": id,
        "learning_id": learningId,
        "strategy_name": strategyName,
        "strategy_version": strategyVersion,
        "symbol": symbol,
        "timeframe": timeframe,
        "market_regime": marketRegime,
        "learning_type": learningType,
        "action": action,
        "description": description,
        "previous_win_rate": previousWinRate,
        "previous_profit_factor": previousProfitFactor,
        "previous_net_profit": previousNetProfit,
        "new_win_rate": newWinRate,
        "new_profit_factor": newProfitFactor,
        "new_net_profit": newNetProfit,
        "confidence": confidence,
        "improvement": improvement,
        "old_parameters": oldParameters,
        "new_parameters": newParameters,
        "trades_analyzed": tradesAnalyzed,
        "trades_improved": tradesImproved,
        "trades_rejected": tradesRejected,
        "success": success,
        "message": message,
        "error": error,
        "created_at": createdAt.toIso8601String(),
      };

  String toRawJson() => jsonEncode(toJson());

  factory LearningLogModel.fromRawJson(String source) =>
      LearningLogModel.fromJson(jsonDecode(source));

  LearningLogModel copyWith({
    String? id,
    String? learningId,
    String? strategyName,
    int? strategyVersion,
    String? symbol,
    String? timeframe,
    String? marketRegime,
    String? learningType,
    String? action,
    String? description,
    double? previousWinRate,
    double? previousProfitFactor,
    double? previousNetProfit,
    double? newWinRate,
    double? newProfitFactor,
    double? newNetProfit,
    double? confidence,
    bool? improvement,
    Map<String, dynamic>? oldParameters,
    Map<String, dynamic>? newParameters,
    int? tradesAnalyzed,
    int? tradesImproved,
    int? tradesRejected,
    bool? success,
    String? message,
    String? error,
    DateTime? createdAt,
  }) {
    return LearningLogModel(
      id: id ?? this.id,
      learningId: learningId ?? this.learningId,
      strategyName: strategyName ?? this.strategyName,
      strategyVersion: strategyVersion ?? this.strategyVersion,
      symbol: symbol ?? this.symbol,
      timeframe: timeframe ?? this.timeframe,
      marketRegime: marketRegime ?? this.marketRegime,
      learningType: learningType ?? this.learningType,
      action: action ?? this.action,
      description: description ?? this.description,
      previousWinRate: previousWinRate ?? this.previousWinRate,
      previousProfitFactor:
          previousProfitFactor ?? this.previousProfitFactor,
      previousNetProfit:
          previousNetProfit ?? this.previousNetProfit,
      newWinRate: newWinRate ?? this.newWinRate,
      newProfitFactor:
          newProfitFactor ?? this.newProfitFactor,
      newNetProfit: newNetProfit ?? this.newNetProfit,
      confidence: confidence ?? this.confidence,
      improvement: improvement ?? this.improvement,
      oldParameters: oldParameters ?? this.oldParameters,
      newParameters: newParameters ?? this.newParameters,
      tradesAnalyzed: tradesAnalyzed ?? this.tradesAnalyzed,
      tradesImproved: tradesImproved ?? this.tradesImproved,
      tradesRejected: tradesRejected ?? this.tradesRejected,
      success: success ?? this.success,
      message: message ?? this.message,
      error: error ?? this.error,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  bool get isSuccessful => success;

  bool get hasImproved => improvement;

  double get winRateDifference =>
      newWinRate - previousWinRate;

  double get profitFactorDifference =>
      newProfitFactor - previousProfitFactor;

  @override
  String toString() {
    return '''
LearningLogModel(
  strategy: $strategyName
  learningType: $learningType
  improvement: $improvement
  confidence: $confidence
)
''';
  }
}