class DashboardModel {
  //========================
  // Market
  //========================

  final double btcPrice;
  final double btcChange;

  final double ethPrice;
  final double ethChange;

  final String marketSentiment;
  final String marketRegime;

  final String fearGreed;
  final String volatility;

  //========================
  // Signal
  //========================

  final String currentSignal;

  final double confidence;

  //========================
  // Performance
  //========================

  final double todayPnL;

  final double totalPnL;

  final int openTrades;

  final int totalTrades;

  final double winRate;

  //========================
  // Strategy
  //========================

  final String activeStrategy;

  final int strategyVersion;

  //========================
  // Scheduler
  //========================

  final bool schedulerRunning;

  //========================
  // Learning
  //========================

  final String lastLearning;

  //========================
  // Updated Time
  //========================

  final DateTime lastUpdated;

  const DashboardModel({
    required this.btcPrice,
    required this.btcChange,
    required this.ethPrice,
    required this.ethChange,
    required this.marketSentiment,
    required this.marketRegime,
    required this.fearGreed,
    required this.volatility,
    required this.currentSignal,
    required this.confidence,
    required this.todayPnL,
    required this.totalPnL,
    required this.openTrades,
    required this.totalTrades,
    required this.winRate,
    required this.activeStrategy,
    required this.strategyVersion,
    required this.schedulerRunning,
    required this.lastLearning,
    required this.lastUpdated,
  });

  factory DashboardModel.empty() {
    return DashboardModel(
      btcPrice: 0,
      btcChange: 0,
      ethPrice: 0,
      ethChange: 0,
      marketSentiment: "NEUTRAL",
      marketRegime: "RANGING",
      fearGreed: "Neutral",
      volatility: "Low",
      currentSignal: "WAIT",
      confidence: 0,
      todayPnL: 0,
      totalPnL: 0,
      openTrades: 0,
      totalTrades: 0,
      winRate: 0,
      activeStrategy: "N/A",
      strategyVersion: 1,
      schedulerRunning: false,
      lastLearning: "Never",
      lastUpdated: DateTime.now(),
    );
  }

  factory DashboardModel.fromJson(Map<String, dynamic> json) {
    return DashboardModel(
      btcPrice: (json["btc_price"] ?? 0).toDouble(),
      btcChange: (json["btc_change"] ?? 0).toDouble(),

      ethPrice: (json["eth_price"] ?? 0).toDouble(),
      ethChange: (json["eth_change"] ?? 0).toDouble(),

      marketSentiment: json["market_sentiment"] ?? "NEUTRAL",
      marketRegime: json["market_regime"] ?? "RANGING",

      fearGreed: json["fear_greed"] ?? "Neutral",
      volatility: json["volatility"] ?? "Low",

      currentSignal: json["current_signal"] ?? "WAIT",

      confidence: (json["confidence"] ?? 0).toDouble(),

      todayPnL: (json["today_pnl"] ?? 0).toDouble(),

      totalPnL: (json["total_pnl"] ?? 0).toDouble(),

      openTrades: json["open_trades"] ?? 0,

      totalTrades: json["total_trades"] ?? 0,

      winRate: (json["win_rate"] ?? 0).toDouble(),

      activeStrategy: json["active_strategy"] ?? "N/A",

      strategyVersion: json["strategy_version"] ?? 1,

      schedulerRunning: json["scheduler_running"] ?? false,

      lastLearning: json["last_learning"] ?? "Never",

      lastUpdated: json["last_updated"] != null
          ? DateTime.parse(json["last_updated"])
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "btc_price": btcPrice,
      "btc_change": btcChange,
      "eth_price": ethPrice,
      "eth_change": ethChange,
      "market_sentiment": marketSentiment,
      "market_regime": marketRegime,
      "fear_greed": fearGreed,
      "volatility": volatility,
      "current_signal": currentSignal,
      "confidence": confidence,
      "today_pnl": todayPnL,
      "total_pnl": totalPnL,
      "open_trades": openTrades,
      "total_trades": totalTrades,
      "win_rate": winRate,
      "active_strategy": activeStrategy,
      "strategy_version": strategyVersion,
      "scheduler_running": schedulerRunning,
      "last_learning": lastLearning,
      "last_updated": lastUpdated.toIso8601String(),
    };
  }

  DashboardModel copyWith({
    double? btcPrice,
    double? btcChange,
    double? ethPrice,
    double? ethChange,
    String? marketSentiment,
    String? marketRegime,
    String? fearGreed,
    String? volatility,
    String? currentSignal,
    double? confidence,
    double? todayPnL,
    double? totalPnL,
    int? openTrades,
    int? totalTrades,
    double? winRate,
    String? activeStrategy,
    int? strategyVersion,
    bool? schedulerRunning,
    String? lastLearning,
    DateTime? lastUpdated,
  }) {
    return DashboardModel(
      btcPrice: btcPrice ?? this.btcPrice,
      btcChange: btcChange ?? this.btcChange,
      ethPrice: ethPrice ?? this.ethPrice,
      ethChange: ethChange ?? this.ethChange,
      marketSentiment: marketSentiment ?? this.marketSentiment,
      marketRegime: marketRegime ?? this.marketRegime,
      fearGreed: fearGreed ?? this.fearGreed,
      volatility: volatility ?? this.volatility,
      currentSignal: currentSignal ?? this.currentSignal,
      confidence: confidence ?? this.confidence,
      todayPnL: todayPnL ?? this.todayPnL,
      totalPnL: totalPnL ?? this.totalPnL,
      openTrades: openTrades ?? this.openTrades,
      totalTrades: totalTrades ?? this.totalTrades,
      winRate: winRate ?? this.winRate,
      activeStrategy: activeStrategy ?? this.activeStrategy,
      strategyVersion: strategyVersion ?? this.strategyVersion,
      schedulerRunning:
          schedulerRunning ?? this.schedulerRunning,
      lastLearning: lastLearning ?? this.lastLearning,
      lastUpdated: lastUpdated ?? this.lastUpdated,
    );
  }

  bool get isBullish =>
      marketSentiment.toUpperCase() == "BULLISH";

  bool get isBearish =>
      marketSentiment.toUpperCase() == "BEARISH";

  bool get isBuy =>
      currentSignal.toUpperCase() == "BUY";

  bool get isSell =>
      currentSignal.toUpperCase() == "SELL";

  bool get isWait =>
      currentSignal.toUpperCase() == "WAIT";

  @override
  String toString() {
    return '''
DashboardModel(
  BTC: $btcPrice
  ETH: $ethPrice
  Signal: $currentSignal
  Confidence: $confidence
  WinRate: $winRate
  ActiveStrategy: $activeStrategy
)
''';
  }
}